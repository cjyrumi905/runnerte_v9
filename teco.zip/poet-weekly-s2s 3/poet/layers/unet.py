# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.
# Local S2S adaptation
# - Support metadata embedding

import logging
from typing import Optional, Sequence

import torch
from hydra.utils import get_class

from ens_transformer.layers.conv import EnsConv2d
from ens_transformer.layers.ens_wrapper import EnsembleWrapper
from ens_transformer.layers.padding import EarthPadding
from poet.layers.conv import EnsConvTranspose2d


logger = logging.getLogger(__name__)


class UnetEncoder(torch.nn.Module):
    def __init__(
            self,
            in_channels: int = 3,
            metadata_channels: int = 0,
            n_channels: Sequence = (16, 32, 64),
            convolutions_per_depth: int = 2,
            kernel_size: int = 5,
            pooling: int = 2,
            activation: str = 'torch.nn.SELU'
    ):
        super().__init__()
        assert convolutions_per_depth >= 1
        old_channels = in_channels
        self.encoder = []
        for n, curr_channel in enumerate(n_channels):
            modules = list()
            if n > 0:
                modules.append(EnsembleWrapper(torch.nn.MaxPool2d(pooling)))
            for m in range(convolutions_per_depth):
                modules.append(EarthPadding((kernel_size - 1) // 2))
                modules.append(EnsConv2d(
                    old_channels, curr_channel, kernel_size=kernel_size
                ))
                modules.append(get_class(activation)(inplace=True))
                old_channels = curr_channel
            self.encoder.append(torch.nn.Sequential(*modules))
        self.n_channels = n_channels
        self.activation = activation
        self.kernel_size = kernel_size
        self.pooling = pooling

        self.encoder = torch.nn.ModuleList(self.encoder)
        
        if metadata_channels > 0:
            # Metadata comes as CxHxW, so we can use standard Conv2d and expand to ensemble dim later
            self.metadata_embedding = torch.nn.Sequential(
            *[
                torch.nn.Conv2d(metadata_channels, n_channels[0], kernel_size=1),
                torch.nn.Conv2d(n_channels[0], n_channels[0], kernel_size=1),
                torch.nn.Conv2d(n_channels[0], n_channels[0], kernel_size=1),
            ]
            )
            # Since we use additive embedding, start with no effect by initializing weights as zero
            for layer in self.metadata_embedding:
                torch.nn.init.zeros_(layer.weight)
                torch.nn.init.zeros_(layer.bias)

    def forward_metadata_embedding(self, metadata: torch.Tensor) -> torch.Tensor:
        """
        Metadata arrives as C, H, W or B, C, H, W. Ensemble inputs are B, E, C, H, W.
        """
        # Expand to batch dim if needed
        if metadata.dim() == 3:
            metadata = metadata.unsqueeze(0)
        metadata = self.metadata_embedding(metadata)
        # Expand to ensemble dim
        metadata = metadata.unsqueeze(1)
        # This 1, 1, C, H, W should be fine now since the addition can broadcast
        return metadata

    def forward(self, inputs: torch.Tensor, metadata: Optional[torch.Tensor]) -> Sequence:
        outputs = []
        for l, layer in enumerate(self.encoder):
            outputs.append(layer(inputs))
            if metadata is not None and l == 0:
                # Add metadata embedding to the first layer
                metadata = self.forward_metadata_embedding(metadata)
                outputs[0] = outputs[0] + metadata
            inputs = outputs[-1]
        return outputs


class UnetDecoder(torch.nn.Module):
    def __init__(
            self,
            in_channels: Sequence = (16, 32, 64),
            n_channels: Sequence = (64, 32, 16),
            out_channels: int = 1,
            convolutions_per_depth: int = 2,
            kernel_size: int = 5,
            pooling: int = 2,
            activation: str = 'torch.nn.SELU',
            output_padding_latitude: bool = False
    ):
        super().__init__()
        assert convolutions_per_depth >= 0
        assert len(in_channels) == len(n_channels)
        in_channels = list(in_channels[::-1])
        self.decoder = []
        for n, curr_channel in enumerate(n_channels):
            modules = list()
            # Regular convolutions
            for m in range(convolutions_per_depth - 1):
                if n == 0 and m == 0:
                    in_ch = in_channels[n]
                elif m == 0 and n > 0:
                    in_ch = in_channels[n] + curr_channel
                else:
                    in_ch = curr_channel
                modules.append(EarthPadding((kernel_size - 1) // 2))
                modules.append(EnsConv2d(in_ch, curr_channel, kernel_size=kernel_size))
                modules.append(get_class(activation)(inplace=True))
            if n < len(n_channels) - 1:
                # Add the upsample conv
                out_pad = (1, 0) if (n == len(n_channels) - 2) and output_padding_latitude else 0
                modules.append(EnsConvTranspose2d(curr_channel, n_channels[n + 1], kernel_size=2, stride=2,
                                                  output_padding=out_pad))
                modules.append(get_class(activation)(inplace=True))
            else:
                # Add the output layer
                modules.append(EnsConv2d(curr_channel, out_channels, kernel_size=1))
            self.decoder.append(torch.nn.Sequential(*modules))
        self.n_channels = n_channels
        self.activation = activation
        self.kernel_size = kernel_size
        self.pooling = pooling

        self.decoder = torch.nn.ModuleList(self.decoder)

    def forward(self, inputs: Sequence) -> torch.Tensor:
        x = inputs[-1]
        for n, layer in enumerate(self.decoder):
            x = layer(x)
            if n < len(self.decoder) - 1:
                x = torch.cat([x, inputs[-2 - n]], dim=2)
        return x
