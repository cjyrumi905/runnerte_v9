# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.

__version__ = '0.0.1'
