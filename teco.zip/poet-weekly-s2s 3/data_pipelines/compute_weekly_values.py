from typing import Optional

import click
import numpy as np
from tqdm import tqdm
import xarray as xr


def compute_weekly_running_mean(
    dataset: xr.Dataset,
    time_dim: str = "time",
    time_dim_values: Optional[list] = None,
    coord_based_on: str = "end",  # Options: "start" or "end"
    include_boundary: bool = True,
    concatenate: bool = True,
) -> xr.Dataset:
    """
    Computes a weekly running mean from an observation dataset.

    Parameters:
        dataset (xr.Dataset): The input dataset with a time dimension.
        time_dim (str): The name of the time dimension in the dataset.
        coord_based_on (str): Whether to assign coordinates based on the "start" or "end" of the running mean window.
        include_boundary (bool): Whether to include the first (if coord_based_on="end") or last (if
            coord_based_on="start") index in the computation of the window.

    Returns:
        xr.Dataset: A dataset with the weekly running mean computed.
    """
    # Ensure the time dimension exists
    if time_dim not in dataset.dims:
        raise ValueError(f"Time dimension '{time_dim}' not found in the dataset.")

    # Create a new dataset to store the results
    result = []

    # Iterate over the time coordinates
    for current_time in time_dim_values or dataset[time_dim].values:
        # Define the time window
        if coord_based_on == "end":
            start_time = current_time - np.timedelta64(7, "D")
            end_time = current_time
        elif coord_based_on == "start":
            start_time = current_time
            end_time = current_time + np.timedelta64(7, "D")
        else:
            raise ValueError("coord_based_on must be either 'start' or 'end'.")

        # Adjust the window to include the boundary if specified. xarray.sel is inclusive by default
        if not include_boundary:
            if coord_based_on == "end":
                start_time += np.timedelta64(1, "ns")
            elif coord_based_on == "start":
                end_time -= np.timedelta64(1, "ns")

        # Select the data within the time window
        window_data = dataset.sel({time_dim: slice(start_time, end_time)})

        # Compute the mean for the window
        window_mean = window_data.mean(dim=time_dim)

        # Assign the coordinate based on the specified option
        window_mean = window_mean.assign_coords({time_dim: current_time})

        result.append(window_mean)

    # Combine the results into a single dataset
    if concatenate:
        return xr.concat(result, dim=time_dim)
    return result


@click.group()
def cli():
    pass


@cli.command(name="compute", short_help="Compute weekly running mean of a zarr store.")
@click.option(
    '--input-path',
    type=click.Path(exists=True),
    help='Path to the input zarr store',
)
@click.option(
    '--output-path',
    type=click.Path(),
    help='Path to the output zarr store',
)
@click.option(
    '--time-dim',
    type=str,
    default='time',
    help='Name of the time dimension in the dataset',
)
@click.option(
    '--time-dim-values',
    type=str,
    default=None,
    help='Comma-separated list of time dimension values to compute the running mean for. '
         'If not provided, all time steps will be used. If integers, assumes they are Timedelta in hours.',
)
@click.option(
    '--coord-based-on',
    type=click.Choice(['start', 'end'], case_sensitive=False),
    default='start',
    help='Whether to assign coordinates based on the start or end of the running mean window',
)
@click.option(
    '--include-boundary',
    is_flag=True,
    help='Whether to include the first or last index in the computation of the window',
)
@click.option(
    '--write-by-time-step',
    is_flag=True,
    help='Whether to write the output sequentially, one time step at a time',
)
@click.option(
    '--load-in-memory',
    is_flag=True,
    help='If True, loads all data into memory before computing the running mean',
)
@click.option(
    '--overwrite',
    is_flag=True,
    help='Whether to overwrite the output zarr store if it already exists',
)
def compute(
    input_path: str,
    output_path: str,
    time_dim: str,
    time_dim_values: Optional[str],
    coord_based_on: str,
    include_boundary: bool,
    write_by_time_step: bool,
    load_in_memory: bool,
    overwrite: bool,
):
    """
    Compute weekly running mean from an observation dataset and save it to a zarr store.
    """
    # Check a given value for time_dim_values
    if time_dim_values is not None:
        # Convert the comma-separated string to a list of values
        time_dim_values = time_dim_values.split(',')
        # Convert to numpy timedelta64 if they are integers
        try:
            time_dim_values = [np.timedelta64(int(value), 'h') for value in time_dim_values]
        except ValueError:
            # If conversion fails, keep as strings
            pass
    # Open the input dataset
    ds = xr.open_zarr(input_path)

    if load_in_memory:
        # Load the dataset into memory
        print("Loading dataset into memory...")
        ds = ds.load()

    # Compute the weekly running mean
    result = compute_weekly_running_mean(
        ds,
        time_dim=time_dim,
        time_dim_values=time_dim_values,
        coord_based_on=coord_based_on,
        include_boundary=include_boundary
    )

    # Fix for encoding of string coordinates
    for coord in result.coords:
        if 'filters' in result[coord].encoding:
            del result[coord].encoding['filters']

    if write_by_time_step:
        # Write the dataset without computing
        print("writing dataset metadata...")
        result.to_zarr(output_path, mode='w' if overwrite else 'w-', compute=False, consolidated=True)
        for t, _ in enumerate(tqdm(result['time'].values)):
            # Write the dataset for each time step
            result.isel(time=slice(t, t + 1)).drop_vars([c for c in result.coords if c != 'time']).to_zarr(
                output_path,
                mode='a',
                region={'time': slice(t, t + 1)},
                consolidated=True,
            )
    else:
        print("writing dataset...")
        result.to_zarr(output_path, mode='w' if overwrite else 'w-', consolidated=True)


if __name__ == "__main__":
    cli()
