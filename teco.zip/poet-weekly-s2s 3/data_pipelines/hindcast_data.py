import gc
import logging
import multiprocessing as mp
import os
from pathlib import Path
import sys
import time
import traceback
import tracemalloc
from typing import Literal, Optional, Sequence, Tuple

import click
from hydra.utils import instantiate
import numpy as np
import pandas as pd
from tqdm import tqdm
from tqdm.contrib.logging import logging_redirect_tqdm
import yaml
import zarr

from data_pipelines.utils import VariableDescription, create_latlon_coords, consolidate_metadata, get_fill_value, \
    get_ecmwf_hindcast_dates, get_hindcast_dates, get_config_variable_names_list

# Setup logging
logger = logging.getLogger(__name__)
logger.setLevel("INFO")
# Write everything to `stderr`, which is unbuffered.
stream_handler = logging.StreamHandler(sys.stderr)
formatter = logging.Formatter("[%(levelname)s][%(asctime)s][PID=%(process)d]"
                              "[%(filename)s:%(lineno)d] - %(message)s")
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)

EVENT = None


def create_variable(
        desc: VariableDescription,
        out: zarr.hierarchy.Group, # type: ignore
        exists_ok: bool = False,
) -> zarr.core.Array: # type: ignore
    """Create a variable in `out`."""

    # Determine the chunk size. Default to only time chunking.
    chunks: tuple[int, ...]
    assert desc.shape is not None
    if desc.chunking is not None:
        chunks = desc.chunking
    elif len(desc.shape) == 1:
        # This is a coordinate. Save it in one chunk.
        chunks = desc.shape
    else:
        # Default to chunking only in time.
        chunks = (1,) + desc.shape[1:]

    # Check if the dimensionality is supported.
    assert desc.shape is not None

    # Determine the fill value.
    fill_value = get_fill_value(desc)
    logger.debug(f"Using fill value `{fill_value}` for variable `{desc.name}`.")

    # Try to create the variable.
    try:
        v = out.create_dataset(
            desc.name,
            shape=desc.shape,
            chunks=chunks,
            dtype=desc.dtype,
            fill_value=fill_value,
            compressor=zarr.Blosc(clevel=5),
            # Leave `order` to the default.
        )
        # We need to communicate the dimension names to `xarray` in this way.
        v.attrs["_ARRAY_DIMENSIONS"] = list(desc.dim_names)
        # Set the units, description, scale factor and offset.
        if desc.units:
            v.attrs["units"] = desc.units
        if desc.description:
            v.attrs["description"] = desc.description
        if desc.scale_factor is not None:
            v.attrs["scale_factor"] = desc.scale_factor
        if desc.add_offset is not None:
            v.attrs["add_offset"] = desc.add_offset
    except zarr.errors.ContainsArrayError: # type: ignore
        # The array already exists. We need to open it instead.
        if exists_ok:
            logger.warning(f"Tried to create variable `{desc.name}` but it already exists.")
            v = out[desc.name]
        else:
            raise

    return v


def _generate_hindcast_dates_sequence(
        start_date: pd.Timestamp,
        end_date: pd.Timestamp,
        frequency: str,
        hindcast_years: int,
        world_size: int,
        global_rank: int,
) -> Sequence[Tuple[pd.Timestamp, pd.Timestamp]]:
    """Generate a sequence of date, hindcast date for this process."""
    if frequency.startswith("ecmwf"):
        # Get the ECMWF hindcast dates
        all_dates = get_ecmwf_hindcast_dates(
            start_date.round('1d'),
            end_date.round('1d'),
            extended_ensemble=not frequency.endswith("hres"),
            hindcast_years=hindcast_years
        )
    else:
        all_dates = get_hindcast_dates(
            start_date.round('1d'),
            end_date.round('1d'),
            frequency,
            hindcast_years=hindcast_years
        )
    # Split data by contiguous blocks, returning the one for this process
    chunks_per_rank = len(all_dates) // world_size
    chunks_modulo = len(all_dates) % world_size
    start = global_rank * chunks_per_rank + min(chunks_modulo, global_rank)
    end = start + chunks_per_rank + int(global_rank < chunks_modulo)
    this_rank_times = all_dates[start:end]
    return this_rank_times


def create_impl(
        path: Path,
        config_path: Path,
        start_time: pd.Timestamp,
        end_time: pd.Timestamp,
        frequency: str,
        hindcast_years: int,
        step_slice: str,
        resolution: float,
        members: int,
        chunk_members: bool = False,
        mode: Literal["w-", "w", "a"] = "w-"
) -> None:
    """
    Create cloud-optimized Zarr store.
    """
    logger.info(f"Creating Zarr store at `{path}`...")

    # Check coordinates
    date_range = _generate_hindcast_dates_sequence(
        start_time,
        end_time,
        frequency,
        hindcast_years,
        1,
        0,
    )
    date_range = pd.DatetimeIndex([d[1] for d in date_range])
    if any(date_range.duplicated()):
        raise ValueError("The date range contains duplicates. These can be caused by matching hindcast dates. "
                         "The current implementation does not support this.")
    nlat, nlon, target_lat, target_lon = create_latlon_coords(resolution)
    start_step, end_step, step_step = [pd.Timedelta(s).to_numpy() for s in step_slice.split(":")]
    num_steps = int((end_step - start_step) / step_step) + 1
    if num_steps < 1:
        raise ValueError(f"Invalid step slice `{step_slice}`. The start time must be before the end time.")
    steps = np.linspace(start_step.astype('float'), end_step.astype('float'), num_steps, dtype="timedelta64[ns]")

    # Get the variable names from the config file
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    variable_names = get_config_variable_names_list(config['data_config'])

    # Create the Zarr store and coordinates
    out: zarr.hierarchy.Group = zarr.open(str(path), mode=mode) # type: ignore
    time_coord = create_variable(
        VariableDescription(
            name="time",
            dim_names=("time",),
            dtype="datetime64[ns]",
            shape=(len(date_range),),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    time_coord[:] = date_range.values

    step_coord = create_variable(
        VariableDescription(
            name="step",
            dim_names=("step",),
            dtype="timedelta64[ns]",
            shape=(num_steps,),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    step_coord[:] = steps

    number_coord = create_variable(
        VariableDescription(
            name="number",
            dim_names=("number",),
            dtype="int32",
            shape=(members,),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    number_coord[:] = np.arange(members, dtype="int32") + 1

    lat_coord = create_variable(
        VariableDescription(
            name="latitude",
            dim_names=("latitude",),
            dtype="float32",
            shape=(nlat,),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    lat_coord[:] = target_lat

    lon_coord = create_variable(
        VariableDescription(
            name="longitude",
            dim_names=("longitude",),
            dtype="float32",
            shape=(nlon,),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    lon_coord[:] = target_lon

    variable_coord = create_variable(
        VariableDescription(
            name="variable",
            dim_names=("variable",),
            dtype="str",
            shape=(len(variable_names),),
            chunking=(-1,),
        ),
        out,
        exists_ok=mode == "a",
    )
    variable_coord[:] = np.array(variable_names, dtype="S").astype("str")

    # Create the data variable
    desc = VariableDescription(
        name="data",
        dim_names=("time", "step", "number", "variable", "latitude", "longitude"),
        dtype="float32",
        shape=(len(date_range), num_steps, members, len(variable_names), nlat, nlon),
        chunking=(1, 1, 1 if chunk_members else members, len(variable_names), nlat, nlon),
        fill_value=np.nan,
        description="Combined data",
        units="unknown",
        scale_factor=None,
        add_offset=None,
    )
    _ = create_variable(
        desc,
        out,
        exists_ok=mode == "a",
    )

    # Consolidate the metadata
    consolidate_metadata(path)
    logger.info("Done!")


def _write_data_step(step, data_handler, output, time_index, retries=3):
    data = data_handler[step]
    if data is None:
        return False

    logger.debug("Writing step %d/%d into time index %d...", step + 1, len(data_handler), time_index)
    attempt = 0
    while True:
        try:
            attempt += 1
            output['data'][time_index, ...] = data
            break
        except Exception as e:  # pylint: disable=broad-exception-caught
            if attempt <= retries:
                time.sleep(1)
            else:
                raise RuntimeError("Exceeded maximum number of attempts.") from e
    del data
    gc.collect()
    return True


def write_impl(
        data_config: dict,
        dates: Sequence[Tuple[pd.Timestamp, pd.Timestamp]],
        output_path: Path,
        global_rank: int,
        disable_resume: bool = False,
        resume_job_id: str = "",
        dry_run: bool = False,
):
    """Implementation of the loop for a single process writing data."""
    global EVENT  # pylint: disable=global-statement
    if 'EVENT' not in globals():
        EVENT = None

    data_handler = instantiate(data_config, dates=dates)
    assert len(dates) == len(data_handler), "Times and data handler should have the same length."

    logger.info("Starting worker %d...", global_rank)

    if not disable_resume:
        status_file = Path(f"{output_path}.{resume_job_id}.status.{global_rank}")
        if status_file.exists():
            with open(status_file, "r") as f:
                resume_index = int(f.read())
                logger.info("Worker %d resuming from index %d.", global_rank, resume_index)
        else:
            resume_index = 0
    else:
        resume_index = 0

    output = zarr.open(str(output_path), mode='a')
    output_times = output['time'][:]

    with logging_redirect_tqdm(loggers=[logger]):
        pbar = tqdm(range(resume_index, len(data_handler)))
        for i in pbar:
            pbar.set_description(f"worker={global_rank}, date={dates[i][0]}, hdate={dates[i][1]}")

            # Check shared event for failures in other processes
            if EVENT is not None and EVENT.is_set():
                logger.error(f'Worker {global_rank} stopped due to event')
                return

            # Check existing files at the time chunk
            logger.debug("Reading data from hindcast date %s", dates[i][1])
            time_index = np.where(output_times == dates[i][1])[0][0]

            # Open the data and write it to the output
            try:
                if dry_run:
                    logger.debug("DRY RUN: Writing step %d/%d into time index %d...",
                                 i + 1, len(data_handler), time_index)
                else:
                    success = _write_data_step(i, data_handler, output, time_index)
                    if not success:
                        logger.warning("No data found for date %s, hdate %s", *dates[i])
            except Exception as e:
                logger.error(f"Caught exception in rank {global_rank} at dates {dates[i]}: {e}")
                logger.error("".join(traceback.format_exception(None, e, e.__traceback__)))
                if EVENT is not None:
                    EVENT.set()
                raise e
            if not disable_resume:
                with open(status_file, "w") as f:
                    f.write(str(i + 1))


def _write_init(shared_event):
    global EVENT  # pylint: disable=global-statement
    EVENT = shared_event


def write_parallel(
        data_config: dict,
        start_time: pd.Timestamp,
        end_time: pd.Timestamp,
        frequency: str,
        hindcast_years: int,
        output_path: Path,
        num_workers: int,
        num_processes: int,
        rank: int,
        disable_resume: bool = False,
        resume_job_id: Optional[str] = None,
        dry_run: bool = False
) -> None:
    """Write a variable in a parallelized environment."""
    logger.info(f"Starting data writing tasks on node rank `{rank}`...")
    # Use parallel processes to perform the copying. Adjust the number of workers and rank appropriately.
    tasks = [
        (
            data_config,
            _generate_hindcast_dates_sequence(
                start_time,
                end_time,
                frequency,
                hindcast_years,
                num_processes * num_workers,
                num_processes * rank + i
            ),
            output_path,
            num_processes * rank + i,
            disable_resume,
            resume_job_id,
            dry_run
        )
        for i in range(num_processes)
    ]
    # Launch context with shared event
    with mp.Manager() as manager:
        shared_event = manager.Event()
        logger.info(f"Starting copying with {num_processes} process(es)...")
        with mp.Pool(initializer=_write_init, initargs=(shared_event,)) as pool:
            ps = pool.starmap_async(write_impl, tasks)
            ps.wait()
        if shared_event.is_set():
            raise RuntimeError(f"Rank {rank} stopped due to event")
    logger.info("Done writing!")


@click.group()
def cli():
    pass


@cli.command(name="create", short_help="Create a Zarr store for cloud-optimized hindcast data.")
@click.option(
    "--path",
    "path",
    type=Path,
    required=True,
    help="Path of created datastore"
)
@click.option(
    "--config-path",
    "config_path",
    type=Path,
    required=True,
    help="Path to data handler config file (instantiable by hydra)"
)
@click.option(
    "--start-time",
    "start_time",
    type=pd.Timestamp,
    required=True,
    help="Start time of the data. Rounded to nearest 00 UTC time."
)
@click.option(
    "--end-time",
    "end_time",
    type=pd.Timestamp,
    required=True,
    help="End time of the data, inclusive. Rounded to nearest 00 UTC time."
)
@click.option(
    "--frequency",
    "frequency",
    type=str,
    default='ecmwf',
    help="Frequency between forecast initializations. Either interpretable by pandas.date_range "
         "or the special case 'ecmwf' for ECMWF's extended ensemble hindcast schedule."
)
@click.option(
    "--hindcast-years",
    "hindcast_years",
    type=int,
    default=20,
    help="Number of hindcast years to use. If set to 0, assumes it is a realtime forecast, not hindcast."
)
@click.option(
    "--step-slice",
    "step_slice",
    type=str,
    default="1d:45d:1d",
    help="Slice for the step (lead time) dimension. Format: start:stop:step."
)
@click.option(
    "--resolution",
    "resolution",
    type=float,
    default=1.5,
    help="Latitude/longitude resolution of the data"
)
@click.option(
    "--members",
    "members",
    type=int,
    default=10,
    help="Number of ensemble members"
)
@click.option(
    "--chunk-members",
    "chunk_members",
    is_flag=True,
    help="Option to chunk each ensemble member."
)
@click.option(
    "--mode",
    "mode",
    type=click.Choice(["w-", "w", "a"]),
    default="w-",
    help="Mode to open the Zarr store in. 'w' will overwrite existing store."
)
def create(
        path: Path,
        config_path: Path,
        start_time: pd.Timestamp,
        end_time: pd.Timestamp,
        frequency: str,
        hindcast_years: int,
        step_slice: str,
        resolution: float,
        members: int,
        chunk_members: bool = False,
        mode: Literal["w-", "w", "a"] = "w-"
) -> None:
    create_impl(
        path=path,
        config_path=config_path,
        start_time=start_time,
        end_time=end_time,
        frequency=frequency,
        hindcast_years=hindcast_years,
        step_slice=step_slice,
        resolution=resolution,
        members=members,
        chunk_members=chunk_members,
        mode=mode
    )


@cli.command(name="write", short_help="Write data to a Zarr store.")
@click.option(
    "--path",
    "path",
    type=Path,
    required=True,
    help="Path of datastore to write into"
)
@click.option(
    "--config-path",
    "config_path",
    type=Path,
    required=True,
    help="Path to data handler config file (instantiable by hydra)"
)
@click.option(
    "--start-time",
    "start_time",
    type=pd.Timestamp,
    required=True,
    help="Start time of the data. Rounded to nearest 00 UTC time."
)
@click.option(
    "--end-time",
    "end_time",
    type=pd.Timestamp,
    required=True,
    help="End time of the data, inclusive. Rounded to nearest 00 UTC time."
)
@click.option(
    "--frequency",
    "frequency",
    type=str,
    default='ecmwf',
    help="Frequency between forecast initializations. Either interpretable by pandas.date_range "
         "or the special case 'ecmwf' for ECMWF's extended ensemble hindcast schedule."
)
@click.option(
    "--hindcast-years",
    "hindcast_years",
    type=int,
    default=20,
    help="Number of hindcast years to use. If set to 0, assumes it is a realtime forecast, not hindcast."
)
@click.option(
    "--num-workers",
    "num_workers",
    type=int,
    default=1,
    help="Number of workers. This is equivalent to the number of nodes."
)
@click.option(
    "--num-processes",
    "num_processes",
    type=int,
    default=1,
    help="Number of processes to use on each worker (node)"
)
@click.option(
    "--rank",
    "rank",
    type=int,
    default=0,
    help="Rank of the process. Environment variable `RANK` will override this."
)
@click.option(
    "--verbose",
    "verbose",
    is_flag=True,
    help="Enable verbose logging"
)
@click.option(
    "--disable-resume",
    "disable_resume",
    is_flag=True,
    help="Disable resuming from previous run"
)
@click.option(
    "--resume-job-id",
    "resume_job_id",
    type=str,
    help="If provided, use this job ID to resume previous run. Defaults to runtime run ID if available."
)
@click.option(
    "--dry-run",
    "dry_run",
    is_flag=True,
    help="Perform a dry run without writing data"
)
def write(
        path: Path,
        config_path: Path,
        start_time: pd.Timestamp,
        end_time: pd.Timestamp,
        frequency: str = 'ecmwf',
        hindcast_years: int = 20,
        num_workers: int = 1,
        num_processes: int = 1,
        rank: int = 0,
        verbose: bool = False,
        disable_resume: bool = False,
        resume_job_id: Optional[str] = None,
        dry_run: bool = False,
):
    """
    Write data to a Zarr store.

    :param path: Path of the Zarr store to write into.
    :param config_path: Path to data handler config file (instantiable by hydra).
    :param start_time: Start time of the data. Rounded to nearest 00 UTC time.
    :param end_time: End time of the data, inclusive. Rounded to nearest 00 UTC time.
    :param frequency: Frequency between forecast initializations. Either interpretable by pandas.date_range
                        or the special case 'ecmwf' for ECMWF's extended ensemble hindcast schedule.
    :param hindcast_years: Number of hindcast years to use. If set to 0, assumes it is a realtime forecast.
    :param num_workers: Number of workers. This is equivalent to the number of nodes.
    :param num_processes: Number of processes to use on each worker (node).
    :param rank: Rank of the process. Environment variable `RANK` will override this.
    :param verbose: Enable verbose logging.
    :param disable_resume: Disable resuming from previous run.
    :param resume_job_id: If provided, use this job ID to resume previous run. Defaults to runtime run ID if available.
    :param dry_run: Perform a dry run without writing data.
    """
    if verbose:
        tracemalloc.start()
        logger.setLevel("DEBUG")

    # Get the data config
    with open(config_path, 'r') as file:
        data_config = yaml.safe_load(file)

    # Rank and ID
    rank = int(os.environ.get("RANK", rank))
    if rank >= num_workers:
        raise ValueError(f"Rank {rank} is too high for the number of workers {num_workers}.")
    resume_job_id = resume_job_id or os.environ.get("RUN_ID", "null")

    # Write the data
    if num_processes == 1:
        write_impl(
            data_config,
            _generate_hindcast_dates_sequence(
                start_time,
                end_time,
                frequency,
                hindcast_years,
                num_workers,
                rank
            ),
            path,
            rank,
            disable_resume,
            resume_job_id,
            dry_run
        )
    else:
        write_parallel(
            data_config,
            start_time,
            end_time,
            frequency,
            hindcast_years,
            path,
            num_workers,
            num_processes,
            rank,
            disable_resume,
            resume_job_id,
            dry_run
        )

    if verbose:
        logger.debug("Memory usage:")
        snapshot = tracemalloc.take_snapshot()
        top_stats = snapshot.statistics('lineno')
        for stat in top_stats[:10]:
            logger.debug(stat)


if __name__ == "__main__":
    # Run the CLI
    cli()
