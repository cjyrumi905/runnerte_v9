import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import xarray as xr
import zarr
from zarr.util import json_loads, json_dumps

logger = logging.getLogger(__name__)


@dataclass()
class VariableDescription:
    """Full description of a variable."""

    name: str
    dim_names: tuple[str, ...]
    dtype: str
    scale_factor: Optional[float] = None
    add_offset: Optional[float] = None
    fill_value: Optional[Any] = None
    units: Optional[str] = None
    description: Optional[str] = None
    alt_name: Optional[str] = None

    shape: Optional[tuple[int, ...]] = None
    chunking: Optional[tuple[int, ...]] = None


def get_fill_value(desc: VariableDescription) -> Any:
    if desc.fill_value is not None:
        return desc.fill_value
    if str(desc.dtype) in {"datetime64[ns]", "timedelta64[ns]"}:
        # For date-related objects, use `None`s.
        return None
    if np.issubdtype(desc.dtype, np.unsignedinteger):
        # set fill value to the maximum value of the data type
        return np.iinfo(desc.dtype).max
    if np.issubdtype(desc.dtype, np.integer):
        # set fill value to the minimum value of the data type
        return np.iinfo(desc.dtype).min
    return float("nan")


def consolidate_metadata(path: Path) -> None:
    """An optimised implementation of `zarr.consolidate_metadata`, from Aurora project."""
    logger.info(f"Consolidating `{path}`...")

    store = zarr.DirectoryStore(path)
    archive = zarr.open(store, "a")

    # Instead of recursively walking through the entire directory structure, let's more cleverly
    # list all files that need to be consolidated.
    folders = archive.keys()
    desired_files = [".zarray", ".zgroup", ".zattrs"]
    listing = [prefix + f for prefix in [""] + [v + "/" for v in folders] for f in desired_files]
    listing = [f for f in listing if (path / f).exists()]

    # Perform the consolidation.
    out = {
        "zarr_consolidated_format": 1,
        "metadata": {key: json_loads(store[key]) for key in listing},
    }
    store[".zmetadata"] = json_dumps(out)

    assert (path / ".zmetadata").exists(), "Consolidation failed."
    logger.info("Consolidation done!")


def create_latlon_coords(
        resolution: float,
        min_latitude: float = -90,
        max_latitude: float = 90,
        min_longitude: float = 0,
        max_longitude: float = 360,
) -> Tuple[int, int, np.ndarray, np.ndarray]:
    """Create latitude and longitude coordinates for a given resolution."""
    nlat = int(np.floor(((max_latitude - min_latitude) / resolution))) + 1
    nlon = int(np.floor(((max_longitude - min_longitude) / resolution)))
    target_lon = np.linspace(min_longitude, max_longitude, num=nlon, endpoint=False)
    target_lat = np.linspace(max_latitude, min_latitude, num=nlat, endpoint=True)
    return nlat, nlon, target_lat, target_lon


def deaccumulate_variable(da: xr.DataArray, coord_indicates_end_time: bool = True) -> xr.DataArray:
    """
    Computes a de-accumulated version of a cumulative variable.

    :param da: The data array to de-accumulate.
    :param coord_indicates_end_time: If True, the coordinate indicates the end time of the accumulation.
    :return: The de-accumulated data array.
    """
    if coord_indicates_end_time:
        return da - da.roll(step=1, roll_coords=False)
    return (da.drop('step') - da.roll(step=1, roll_coords=True)).roll(step=-1, roll_coords=True)


def get_hindcast_date(model_date, years_back):
    """
    Computes the hindcast date for a given model date and number of years back.
    :param model_date: The model date to compute the hindcast date for.
    :param years_back: The number of years back to compute the hindcast date.
    :return: The hindcast date.
    """
    if model_date.month == 2 and model_date.day == 29:
        return model_date.replace(year=model_date.year - int(years_back), day=28)
    return model_date.replace(year=model_date.year - int(years_back))


def get_hindcast_dates(
        start_date: pd.Timestamp,
        end_date: pd.Timestamp,
        frequency: str = '1D',
        hindcast_years: int = 20,
) -> Sequence[Tuple[pd.Timestamp, pd.Timestamp]]:
    """
    Computes the dates for a hindcast initialization from start_date to end_date.

    :param start_date: Start date for the hindcast.
    :param end_date: End date for the hindcast.
    :param frequency: Frequency of the hindcast. Default is '1D'.
    :param hindcast_years: Number of years to include in the hindcast. If set to 0, assumes realtime forecast.
    :return: A list of tuples with the model date and hindcast date
    """
    dates = pd.date_range(start_date, end_date, freq=frequency)
    if hindcast_years == 0:
        return [(date, date) for date in dates]

    hindcast_dates = [(date, get_hindcast_date(date, yb)) for date in dates for yb in range(1, hindcast_years + 1)]
    return hindcast_dates


def get_ecmwf_hindcast_dates(
        start_date: pd.Timestamp,
        end_date: pd.Timestamp,
        extended_ensemble: bool = True,
        hindcast_years: int = 20,
) -> Sequence[Tuple[pd.Timestamp, pd.Timestamp]]:
    """
    Computes the dates for an ECWMF forecast or hindcast initialization from start_date to end_date.

    Prior to 2024-11-11, ECMWF hindcasts were run on Thursdays and Mondays.
    Starting on 2024-11-11, they are run on every odd-numbered day of the year except for Feb 29.
    The short-range ensemble is only run every 4 days, i.e., days 1,5,9,13,17,21,25,29.

    :param start_date: Start date for the hindcast.
    :param end_date: End date for the hindcast.
    :param extended_ensemble: If True, include extended ensemble initialization dates every odd day. Otherwise,
        uses every other odd day.
    :param hindcast_years: Number of years to include in the hindcast. If set to 0, assumes realtime forecast.
    :return: A list of tuples with the model date and hindcast date
    """

    def _get_odd_number_dates(start_date, end_date):
        daily = pd.date_range(start_date, end_date, freq='1D')
        odd_dates = [d for d in daily if d.day % (2 if extended_ensemble else 4) == 1
                     and not (d.month == 2 and d.day == 29)]
        return pd.DatetimeIndex(odd_dates)

    if start_date < pd.Timestamp('2024-11-11'):
        biweekly_end = min(end_date, pd.Timestamp('2024-11-10'))
        dates = pd.date_range(start_date, biweekly_end, freq='W-MON').union(
            pd.date_range(start_date, biweekly_end, freq='W-THU'))
        if end_date >= pd.Timestamp('2024-11-11'):
            dates = dates.union(_get_odd_number_dates(pd.Timestamp('2024-11-11'), end_date))
    else:
        dates = _get_odd_number_dates(start_date, end_date)

    if hindcast_years == 0:
        return [(date, date) for date in dates]

    hindcast_dates = [(date, get_hindcast_date(date, yb)) for date in dates for yb in range(1, hindcast_years + 1)]
    return hindcast_dates


def get_config_variable_names_list(config: dict) -> List[str]:
    """
    Get a list of variable names from the configuration.

    :param config: The `data_config` dictionary.
    :return: A list of variable names.
    """
    variable_names = []
    for _, data_config in config.items():
        for _, new_var in data_config['variables'].items():
            if data_config['type'] == 'pl':
                for level in data_config['levels']:
                    level_var = f"{new_var}_{level}"
                    variable_names.append(level_var)
            else:
                variable_names.append(new_var)
    return variable_names
