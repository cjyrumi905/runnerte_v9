# Licensed under the MIT License.
"""
Downloads ECMWF S2S hindcasts and forecasts from the MARS archive.
"""

import argparse
from itertools import product
from functools import partial
import logging
import multiprocessing
import os
from pathlib import Path
import time

from ecmwfapi import ECMWFDataServer
import pandas as pd

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DEFAULT_RETRIEVE_ARGS = {
    'class': 's2',
    'expver': 'prod',
    'expect': 'any',
}

# Read parameter list. Located in root path of this repository, in 'assets' directory.
PARAMETERS = pd.read_csv(Path(__file__).parent.parent / 'assets' / 'ecmwf_s2s_parameter_list.csv',
                         index_col=0, dtype=str)


def mars_join_param(p):
    return '/'.join([str(pp) for pp in p])


def get_hindcast_date(model_date, years_back):
    if model_date.month == 2 and model_date.day == 29:
        return model_date.replace(year=model_date.year - int(years_back), day=28)
    return model_date.replace(year=model_date.year - int(years_back))


def get_all_params(levtype):
    if levtype == 'sfc':
        return mars_join_param(PARAMETERS.loc[(PARAMETERS['type'] == 'sfc') &
                                              (PARAMETERS['24hourly'] == '1')]['paramId'])
    if levtype == 'sfc6h':
        return mars_join_param(PARAMETERS.loc[(PARAMETERS['type'] == 'sfc') &
                                              (PARAMETERS['6hourly'] == '1')]['paramId'])
    if levtype == 'sfcmean':
        return mars_join_param(PARAMETERS.loc[(PARAMETERS['type'] == 'sfc') &
                                              (PARAMETERS['dailymean'] == '1')]['paramId'])
    return mars_join_param(PARAMETERS.loc[PARAMETERS['type'] == levtype]['paramId'])


def get_default_steps(levtype):
    if levtype == 'sfc':
        return '0/to/1104/by/24'
    if levtype == 'sfcmean':
        return mars_join_param([f'{h}-{h+24}' for h in range(0, 1103, 24)])
    if levtype == 'sfc6h':
        return '0/to/1104/by/6'
    if levtype == 'pl':
        return '0/to/1104/by/24'
    if levtype == 'o2d':
        return mars_join_param([f'{h}-{h+24}' for h in range(0, 1103, 24)])
    raise ValueError(f"Unknown levtype: {levtype}")


def get_ecmwf_hindcast_dates(start_date, end_date):
    """
    Prior to 2024-11-11, ECMWF hindcasts were run on Thursdays and Mondays.
    Starting on 2024-11-11, they are run on every odd-numbered day of the year except for Feb 29.
    """
    def get_odd_number_dates(start_date, end_date):
        daily = pd.date_range(start_date, end_date, freq='1D')
        odd_dates = [d for d in daily if d.day % 2 == 1 and not (d.month == 2 and d.day == 29)]
        return pd.DatetimeIndex(odd_dates)

    if start_date < pd.Timestamp('2024-11-11'):
        biweekly_end = min(end_date, pd.Timestamp('2024-11-10'))
        dates = pd.date_range(start_date, biweekly_end, freq='W-MON').union(
            pd.date_range(start_date, biweekly_end, freq='W-THU'))
        if end_date >= pd.Timestamp('2024-11-11'):
            dates = dates.union(get_odd_number_dates(pd.Timestamp('2024-11-11'), end_date))
    else:
        dates = get_odd_number_dates(start_date, end_date)
    return dates


def retrieve_one_hindcast(model_date, years_back, levtype, levels, steps, is_control, output_dir,
                          overwrite, dry_run=False):
    if levels is None and levtype == 'pl':
        levels = [1000, 925, 850, 700, 500, 300, 200, 100, 50, 10]
    start_time = time.time()

    # Retrieval args
    retrieve_args = dict(DEFAULT_RETRIEVE_ARGS)
    if isinstance(years_back, list):
        hindcast_dates = [get_hindcast_date(model_date, y).strftime('%Y-%m-%d') for y in years_back]
        hindcast_date = None
        retrieve_args['hdate'] = mars_join_param(hindcast_dates)
        stream = 'enfh'
    elif years_back > 0:
        hindcast_date = get_hindcast_date(model_date, years_back)
        retrieve_args['hdate'] = hindcast_date.strftime('%Y-%m-%d')
        stream = 'enfh'
    else:
        stream = 'enfo'
    retrieve_args.update({
        'date': model_date.strftime('%Y-%m-%d'),
        'levtype': 'sfc' if levtype.startswith('sfc') else levtype,
        'param': get_all_params(levtype),
        'stream': stream,
        'time': model_date.strftime('%H:%M:%S'),
        'type': 'cf' if is_control else 'pf',
        'step': steps or get_default_steps(levtype),
    })
    if levels is not None:
        retrieve_args['levelist'] = mars_join_param(levels)
    if not is_control:
        n_ens = 11 if stream == 'enfh' else 101
        retrieve_args['number'] = mars_join_param(range(1, n_ens))

    # Output file check
    if stream == 'enfh':
        hdate = hindcast_date.strftime('%Y%m%d%H%M') if hindcast_date else 'all'
        output_file = (
            f"{model_date.strftime('%Y%m%d%H%M')}_{hdate}_{levtype}"
            f"_{retrieve_args['type']}.grib"
        )
    else:
        output_file = (
            f"{model_date.strftime('%Y%m%d%H%M')}_{levtype}_{retrieve_args['type']}.grib"
        )
    output_path = Path(output_dir) / output_file

    if dry_run:
        logger.info("Retrieve args: %s", retrieve_args)
        logger.info("Output path: %s", output_path)
        return

    if output_path.exists() and not overwrite:
        logger.warning("Output file %s already exists, skipping", output_path)
        return

    logger.debug("Retrieve args: %s", retrieve_args)

    # Check for the existence of account parameters
    os.environ['ECMWF_API_URL'] = 'https://api.ecmwf.int/v1'
    assert 'ECMWF_API_KEY' in os.environ, "ECMWF_API_KEY must be set in environment variables."
    assert 'ECMWF_API_EMAIL' in os.environ, "ECMWF_API_EMAIL must be set in environment variables."
    server = ECMWFDataServer()
    retrieve_args['target'] = str(output_path)
    retrieve_args['dataset'] = 's2s'

    for _ in range(10):
        try:
            # server.execute(retrieve_args, output_path)
            server.retrieve(retrieve_args)
            break
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.error("Failed to retrieve %s: %s", output_path, e)
            if 'USER_QUEUED_LIMIT_EXCEEDED' in str(e):
                logger.info("Sleeping 5 minutes before retrying due to queue limit exceeded")
                time.sleep(300)
                continue
            if 'MARS_RESTRICTED_ACCESS_TO_VALID_DATA' in str(e):
                logger.info("Skipping request for %s: MARS_RESTRICTED_ACCESS_TO_VALID_DATA", output_path)
                break
            return

    logger.info("Retrieved %s in %0.0f seconds", output_path, time.time() - start_time)


def main(args):
    global DEFAULT_RETRIEVE_ARGS  # pylint: disable=global-variable-not-assigned

    # Validate args
    if args.grid is not None:
        if not 1.0 < args.grid < 10:
            raise ValueError("Grid resolution must be between 1 and 10 degrees")
        DEFAULT_RETRIEVE_ARGS['grid'] = f"{args.grid}/{args.grid}"
    if args.years_back is None:
        if args.combine_years:
            raise ValueError("Cannot combine years without specifying years_back.")
        args.years_back = ['0']
    if len(args.years_back) == 1 and args.years_back[0] == 'all':
        args.years_back = [str(d) for d in range(1, 21)]
    args.years_back = [int(yb) for yb in args.years_back]

    os.makedirs(args.output_dir, exist_ok=True)

    # Generate dates
    if args.freq == 'ecmwf':
        dates = get_ecmwf_hindcast_dates(args.start_date, args.end_date)
    else:
        dates = pd.date_range(args.start_date, args.end_date, freq=args.freq)

    retrieve_kwargs = {
        'levtype': args.levtype,
        'levels': args.levels,
        'steps': args.steps,
        'is_control': args.control,
        'output_dir': args.output_dir,
        'overwrite': args.overwrite,
        'dry_run': args.dry_run
    }
    if args.combine_years:
        retrieve_kwargs['years_back'] = args.years_back
        dy_iterator = [(d,) for d in dates]
    else:
        dy_iterator = product(dates, args.years_back)

    retrieve_fn = partial(retrieve_one_hindcast, **retrieve_kwargs)
    if args.num_proc == 1:
        for item in dy_iterator:
            retrieve_fn(*item)
    else:
        with multiprocessing.Pool(args.num_proc) as pool:
            pool.starmap(retrieve_fn, dy_iterator)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-o', '--output-dir', default='/weather-blob/ecmwf-s2s/s2s-project',
                        help="Output directory for downloaded files")
    parser.add_argument('-s', '--start-date', type=pd.Timestamp, required=True,
                        help="Start date of the operational forecast run")
    parser.add_argument('-e', '--end-date', type=pd.Timestamp, required=True,
                        help="End date of the operational forecast run, inclusive")
    parser.add_argument('-f', '--freq', default='ecmwf', type=str,
                        help="Frequency of operational forecast run. Either interpretable by pandas.date_range or "
                             "special case 'ecmwf' for ECMWF's hindcast schedule.")
    parser.add_argument('-y', '--years-back', nargs='+', type=str, default=None,
                        help="Specific hindcast years in the past to download. If not specified, downloads forecast. "
                             "Special case 'all' downloads all hindcasts from 1 to 20 years back.")
    parser.add_argument('--combine-years', action='store_true',
                        help="Combine all hindcast years into a single file")
    parser.add_argument('--levtype', default='sfc', choices=['sfc', 'sfc6h', 'sfcmean', 'pl', 'o2d'],
                        help="Type of variables to download")
    parser.add_argument('-l', '--levels', default=None, type=str, nargs='+',
                        help="Levels to download. If not set, all levels will be downloaded.")
    parser.add_argument('--grid', type=float, default=None,
                        help="Grid resolution in degrees")
    parser.add_argument('--steps', type=str, default=None,
                        help="Steps to download, as str interpretable by MARS. Defaults to all steps. Note that the "
                             "step depends on the `levtype`: \n"
                             "- sfc: 0/to/1104/by/24\n"
                             "- sfc6h: 0/to/1104/by/6\n"
                             "- sfcmean: 0-24/24-48... daily averages\n"
                             "- pl: 0/to/1104/by/24\n"
                             "- o2d: 0-24/24-48... daily averages")
    parser.add_argument('--control', action='store_true',
                        help="Download control forecast")
    parser.add_argument('--origin', type=str, default='ecmf',
                        help="Option to download from different origin")
    parser.add_argument('--overwrite', action='store_true',
                        help="Overwrite existing files")
    parser.add_argument('--num-proc', type=int, default=4,
                        help="Number of processes to use")
    parser.add_argument('--dry-run', action='store_true',
                        help="Print retrieval args and output path, but don't download")
    run_args = parser.parse_args()
    main(run_args)
