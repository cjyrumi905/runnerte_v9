import logging
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import cfgrib
import numpy as np
import pandas as pd
import xarray as xr

from data_pipelines.utils import deaccumulate_variable, create_latlon_coords, get_config_variable_names_list

logger = logging.getLogger(__name__)


class ECMWFHindcastHandler:
    """
    A class to handle ECMWF hindcast data processing.
    """

    def __init__(
            self,
            directory: str,
            dates: Sequence[Tuple[pd.Timestamp, pd.Timestamp]],
            date_format: str,
            data_config: Dict[str, Any],
            members: int = 10,
            lead_time_min: str = '1d',
            lead_time_max: str = '45d',
            resolution: float = 1.5,
            all_hindcasts_directory: Optional[str] = None,
            scaling_log_epsilon: Optional[float] = None,
            chunk_members: bool = False,
            raise_error_on_missing_data: bool = True,
            adjust_lead_times: bool = False,
            **kwargs: Any,
    ):
        """
        Handler for ECMWF hindcast data processing.

        Args:
            directory (str): The directory where the hindcast data is stored.
            dates: Sequence of tuples containing the issue date and hindcast date.
            date_format (str): The format of the date in the hindcast data.
            data_config (dict): Configuration for the hindcast data processing.
            members (int): Number of ensemble members (use 1 for control forecast).
            lead_time_min (str): Minimum lead time for the hindcast data, in pandas Timedelta format.
            lead_time_max (str): Maximum lead time for the hindcast data, in pandas Timedelta format.
            resolution (float): Spatial resolution of the data in degrees.
            all_hindcasts_directory (str, optional): Directory for files containing all hindcast dates instead of
                individual files. Defaults to None (same as directory).
            scaling_log_epsilon (float, optional): Epsilon factor to add when log-scaling a variable. 
                If set, any variable whose new name starts with 'scaled_' will be log-scaled using this value.
            chunk_members (bool): If True, chunk the data by members.
            raise_error_on_missing_data (bool): If True, raise an error if any dataset files are missing.
            adjust_lead_times (bool): If True, adjust the lead times to match the AI weather quest definitions. Daily
                mean variables and any accumulated variables are shifted back by one day to align with the day-of 
                coordinate convention.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self.directory = Path(directory)
        self.dates = dates
        self.date_format = date_format
        self.data_config = data_config
        self.members = members
        self.lead_time_min = pd.Timedelta(lead_time_min)
        self.lead_time_max = pd.Timedelta(lead_time_max)
        self.resolution = resolution
        self.all_hindcasts_directory = Path(all_hindcasts_directory) if all_hindcasts_directory else self.directory
        self.scaling_log_epsilon = scaling_log_epsilon
        self.chunk_members = chunk_members
        self.raise_error_on_missing_data = raise_error_on_missing_data
        self.adjust_lead_times = adjust_lead_times

        self.check_config()

    def check_config(self):
        """
        Check the configuration for the hindcast data processing.
        """
        all_variables = []
        for key, value in self.data_config.items():
            if 'file_name' not in value:
                raise ValueError(f"Missing required key 'file_name' in configuration data.{key}")
            if 'variables' not in value:
                raise ValueError(f"Missing required key 'variables' in configuration data.{key}")
            if 'type' not in value:
                raise ValueError(f"Missing required key 'type' in configuration data.{key}")
            if not isinstance(value['variables'], dict):
                raise ValueError(f"Invalid type for 'variables' in configuration data.{key}. Expected dict.")
            if not all(isinstance(v, str) for v in value['variables'].values()):
                raise ValueError(f"Invalid type for 'variables' in configuration data.{key}. "
                                 f"Expected str for each variable key.")
            if value['type'] == 'pl':
                if 'levels' not in value:
                    raise ValueError(f"Missing required key 'levels' in configuration data.{key}")
                if not isinstance(value['levels'], list) or not all(isinstance(l, int) for l in value['levels']):
                    raise ValueError(f"Invalid type for 'level' in configuration data.{key}. Expected list of ints.")
                all_variables.extend(
                    [f"{value['variables'][var]}_{level}" for var in value['variables'] for level in value['levels']]
                )
            else:
                all_variables.extend(value['variables'].values())
        if len(all_variables) != len(set(all_variables)):
            raise ValueError(f"Duplicate variable names in configuration: {all_variables}")

    def _deaccumulate_and_scale(self, da):
        if 'accum' in da.attrs.get('GRIB_stepType', ''):
            da = deaccumulate_variable(da, coord_indicates_end_time=not self.adjust_lead_times)
        if da.name.startswith('scaled_'):
            if self.scaling_log_epsilon is None:
                logger.warning(f"Scaling log epsilon is not set. The variable {da.name} will not be scaled.")
                return da
            return np.log(da + self.scaling_log_epsilon) - np.log(self.scaling_log_epsilon)
        return da

    def _format_data(self, datasets, config, file_name, hdate_sel=None):
        variable_config_copy = dict(config['variables'])
        is_pl = config['type'] == 'pl'
        missing_levels_ok = config.get('missing_levels_ok', False)
        # Combine requested variables
        data_arrays = []
        for ds in datasets:
            if 'number' in ds.dims:
                ds = ds.isel(number=slice(0, self.members))
                assert ds['number'].size == self.members, \
                    f"Expected {self.members} ensemble members, but found {ds['number'].size} in file `{file_name}`."
            else:
                if self.members > 1:
                    raise ValueError(f"File `{file_name}` does not contain ensemble members, but config "
                                     f"requested {self.members} members.")
            if hdate_sel is not None:
                # Select the hindcast date
                ds = ds.sel(time=hdate_sel)
            for var, new_var in config['variables'].items():
                if var in ds.data_vars:
                    if is_pl:
                        for level in config['levels']:
                            level_var = f"{new_var}_{level}"
                            if level not in ds.coords['isobaricInhPa'].values:
                                if missing_levels_ok:
                                    logger.warning(f"Level `{level}` not found in dataset {ds}.")
                                    continue
                                raise KeyError(f"Level `{level}` not found in dataset {ds}")
                            logger.debug(f"Adding variable `{level_var}")
                            data_arrays.append(self._deaccumulate_and_scale(
                                ds[var].sel(isobaricInhPa=level).rename(level_var).drop('isobaricInhPa')
                            ))
                    else:
                        logger.debug(f"Adding variable `{new_var}`")
                        data_arrays.append(self._deaccumulate_and_scale(ds[var].rename(new_var)))
                    _ = variable_config_copy.pop(var)

        # Check if all variables were found
        if len(variable_config_copy) > 0:
            raise ValueError(f"Missing variables in file `{file_name}`: {list(variable_config_copy.keys())}")

        # Combine the data arrays into a single dataset
        dataset = xr.merge(data_arrays)

        # Adjust step dimension if needed
        if config['type'] == 'sfcmean' and self.adjust_lead_times:
            # Shift the step dimension by one day to align with the AI weather quest definitions
            dataset = dataset.assign_coords(step=dataset['step'] - pd.Timedelta(days=1))

        # Select steps
        dataset = dataset.sel(step=slice(self.lead_time_min, self.lead_time_max))

        # If this is ocean data, interpolate to the main resolution.
        if config['type'] == 'o2d':
            nlat, nlon, target_lat, target_lon = create_latlon_coords(resolution=self.resolution)
            if dataset.dims['latitude'] != nlat or dataset.dims['longitude'] != nlon:
                logger.info(f"Interpolating dataset `{file_name}` to {nlat}x{nlon} grid.")
                dataset = dataset.interp(latitude=target_lat, longitude=target_lon, method='linear').astype('float32')

        # Clean up unwanted coordinates
        coords_to_remove = [
            'heightAboveGround',
            'valid_time',
            'meanSea',
            'nominalTop',
            'surface',
            'depthBelowLandLayer',
            'entireAtmosphere',
            'depthBelowSeaLayer',
            'isothermal',
            'mixedLayerDepthByDensity',
            'oceanSurface'
        ]
        dataset = dataset.drop_vars([c for c in coords_to_remove if c in dataset.coords])

        return dataset

    def _open_and_format_file(self, date, hdate, config):
        is_all_hindcast_file = False

        # Check if the file exists
        file_name = self.directory / config['file_name'].format(
            date=date.strftime(self.date_format),
            hdate=hdate.strftime(self.date_format)
        )
        if not file_name.exists():
            # Try a combined file with all hindcast dates
            all_hindcast_file = self.all_hindcasts_directory / config['file_name'].format(
                date=date.strftime(self.date_format),
                hdate='all'
            )
            if not all_hindcast_file.exists():
                logger.error(f"Did not find either an individual hindcast file at `{file_name}` or a combined file at "
                             f"`{all_hindcast_file}`.")
                return None
            is_all_hindcast_file = True

        # Open the file
        file_name = str(all_hindcast_file if is_all_hindcast_file else file_name)
        logger.info(f"Opening file `{file_name}`")
        dss = cfgrib.open_datasets(
            file_name,
            chunks={'step': 1, 'number': 1 if self.chunk_members else -1, 'latitude': -1, 'longitude': -1},
        )

        dataset = self._format_data(dss, config, file_name, hdate_sel=hdate if is_all_hindcast_file else None)

        return dataset

    def open_and_combine(
            self,
            date: pd.Timestamp,
            hdate: pd.Timestamp
    ):
        """
        Open the grib files containing hindcast data, and combine them into the variable dimension

        Args:
            date (pd.Timestamp): Issue date of the hindcast
            hdate (pd.Timestamp): Hindcast date
        Returns:
            xr.DataArray: DataArray of hindcast data.
        """
        all_datasets = []
        for config in self.data_config.values():
            dataset = self._open_and_format_file(date, hdate, config)
            if dataset is None:
                if self.raise_error_on_missing_data:
                    raise ValueError(f"Failed to open file for type {config['type']}, date {date}, and hdate {hdate}.")
                logger.warning(f"Missing data for type {config['type']}, date {date}, and hdate {hdate}. "
                                f"Skipping this date.")
                return None
            all_datasets.append(dataset)

        # Combine all datasets into a single dataset. Preserve variable order specified in the configs
        variable_names = get_config_variable_names_list(self.data_config)
        combined_dataset = xr.merge(all_datasets)[variable_names]

        # Merge into a single dataarray
        if self.members > 1:
            dims = ['step', 'number', 'variable', 'latitude', 'longitude']
        else:
            dims = ['step', 'variable', 'latitude', 'longitude']
        result = combined_dataset.to_array(dim='variable').rename('data').squeeze().transpose(*dims)
        for attr in list(result.attrs.keys()):
            del result.attrs[attr]

        return result.values

    def __len__(self):
        """
        Returns the number of dates in self.dates.
        """
        return len(self.dates)

    def __getitem__(self, item: int):
        """
        Requests data for a specific index from self.dates.
        """
        date, hdate = self.dates[item]
        return self.open_and_combine(date=date, hdate=hdate)


class ECMWFForecastHandler(ECMWFHindcastHandler):
    """
    A class to handle ECMWF forecast data processing. Extends the ECMWFHindcastHandler to a version that does not 
    expect hindcast dates.
    """

    def __init__(
            self,
            directory: str,
            dates: Sequence[Tuple[pd.Timestamp, pd.Timestamp]],
            date_format: str,
            data_config: Dict[str, Any],
            members: int = 10,
            lead_time_min: str = '1d',
            lead_time_max: str = '45d',
            resolution: float = 1.5,
            scaling_log_epsilon: Optional[float] = None,
            chunk_members: bool = False,
            raise_error_on_missing_data: bool = True,
            **kwargs: Any,
    ):
        """
        Handler for ECMWF forecast data processing.

        Args:
            directory (str): The directory where the forecast data is stored.
            dates (Sequence[Tuple[pd.Timestamp, pd.Timestamp]]): Sequence of tuples containing the issue date and
                forecast date.
            date_format (str): The format of the date in the forecast data.
            data_config (dict): Configuration for the forecast data processing.
            members (int): Number of ensemble members (use 1 for control forecast).
            lead_time_min (str): Minimum lead time for the forecast data, in pandas Timedelta format.
            lead_time_max (str): Maximum lead time for the forecast data, in pandas Timedelta format.
            resolution (float): Spatial resolution of the data in degrees.
            scaling_log_epsilon (float, optional): Epsilon factor to add when log-scaling a variable. 
                If set, any variable whose new name starts with 'scaled_' will be log-scaled using this value.
            chunk_members (bool): If True, chunk the data by members.
            raise_error_on_missing_data (bool): If True, raise an error if any dataset files are missing.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(
            directory=directory,
            dates=dates,
            date_format=date_format,
            data_config=data_config,
            members=members,
            lead_time_min=lead_time_min,
            lead_time_max=lead_time_max,
            resolution=resolution,
            scaling_log_epsilon=scaling_log_epsilon,
            chunk_members=chunk_members,
            raise_error_on_missing_data=raise_error_on_missing_data,
        )

    def _open_and_format_file(self, date, hdate, config):  # pylint: disable=unused-argument
        # Check if the file exists
        file_name = self.directory / config['file_name'].format(
            date=date.strftime(self.date_format),
        )
        if not file_name.exists():
            logger.error(f"Did not find file at `{file_name}`.")
            return None

        # Open the file
        logger.info(f"Opening file `{file_name}`")
        dss = cfgrib.open_datasets(
            str(file_name),
            chunks={'step': 1, 'number': 1 if self.chunk_members else -1, 'latitude': -1, 'longitude': -1},
        )

        dataset = self._format_data(dss, config, file_name, hdate_sel=None)

        return dataset
