# Security Policy

## Reporting a vulnerability

Do not disclose suspected vulnerabilities in public issues. Use the hosting platform's private vulnerability-reporting feature, if enabled, or contact the repository maintainers privately.

Please include the affected component, relevant version or commit, reproduction steps, and potential impact. Do not include secrets, credentials, or sensitive operational data in a report.
