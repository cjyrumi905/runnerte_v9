# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.
# Local S2S adaptation
# - Update data APIs
# - Updates to the model instantiation including total_num_steps

import logging
import os
from pathlib import Path

import hydra
from hydra.utils import instantiate
from omegaconf import open_dict
import pytorch_lightning as pl
import torch

from poet.utils import get_model_checkpoint_path

logger = logging.getLogger(__name__)
logging.getLogger('cfgrib').setLevel(logging.ERROR)
logging.getLogger('matplotlib').setLevel(logging.ERROR)


@hydra.main(config_path='../configs/poet', config_name='config', version_base='1.1')
def train(cfg):
    work_directory = Path(os.getcwd())
    logger.info(f"experiment working directory: {work_directory}")

    # Tensor core precision
    if cfg.tensor_core_precision is not None:
        torch.set_float32_matmul_precision(cfg.tensor_core_precision)

    # Data module
    data_module = instantiate(cfg.data.module)
    data_module.setup()
    # TODO: support multiple variables to compute original forecast metrics  # pylint: disable=fixme
    target_variable = str(data_module.train_dataset.ds.channel_out.values[0])
    try:
        raw_input_channel = list(data_module.train_dataset.ds.channel_in).index(target_variable)
        logger.debug(f"computing metrics on raw forecasts for variable '{target_variable}'")
    except ValueError:
        logger.warning(f"unable to find {target_variable} in input variables to compute raw forecast metrics")
        raw_input_channel = None

    # Model
    input_channels = data_module.train_dataset.ds.sizes['channel_in']
    output_channels = data_module.train_dataset.ds.sizes['channel_out']
    metadata_channels = 0
    if cfg.data.get('constants', None) is not None:
        metadata_channels += data_module.train_dataset.ds.sizes['channel_c']
    metadata_channels += int(cfg.data.get('add_lead_time', 0))
    metadata_channels += int(cfg.data.get('insolation_type', None) is not None)
    with open_dict(cfg):
        cfg.model['input_channels'] = input_channels
        cfg.model['output_channels'] = output_channels
        cfg.model['metadata_channels'] = metadata_channels
        cfg.model['raw_input_channel'] = raw_input_channel
        cfg.model['total_num_steps'] = (len(data_module.train_dataset) * cfg.trainer.max_epochs
                                        // cfg.trainer.devices // cfg.trainer.get('num_nodes', 1))
    network = instantiate(cfg.model)
    network.hparams['batch_size'] = cfg.batch_size

    # Set up checkpoint resuming for automatic restarts.
    # First, check if user-specified checkpoint exists. Resumes will override user-specified checkpoints.
    if cfg.get('checkpoint_path', None) is not None and not os.path.exists(cfg['checkpoint_path']):
        raise FileNotFoundError(f"checkpoint not found: {cfg['checkpoint_path']}")
    if cfg.get('check_for_resume', True):
        # Get expected checkpoint path for automatically resuming, if not specified
        resume_ckpt_path = get_model_checkpoint_path(work_directory)
        if resume_ckpt_path is None or not os.path.exists(resume_ckpt_path):
            resume_msg = f"Starting from given checkpoint {cfg['checkpoint_path']}" if \
                cfg.get('checkpoint_path', None) is not None else "Starting new training iteration."
            logger.warning(f"did not find expected checkpoint for resuming ({resume_ckpt_path}). {resume_msg}")
        else:
            logger.info(f"resuming training from checkpoint {resume_ckpt_path}")
            cfg['checkpoint_path'] = resume_ckpt_path

    # Optional override if model is being used on CPU for sanity check
    if cfg.get('move_model_to_gpu', False):
        network = network.to(f'cuda:{os.environ.get("LOCAL_RANK", 0)}')
    logger.debug(pl.utilities.model_summary.summarize(network, max_depth=-1))

    # Callbacks for trainer
    if cfg.callbacks is not None:
        callbacks = []
        for _, callback_cfg in cfg.callbacks.items():
            curr_callback: pl.callbacks.Callback = instantiate(callback_cfg)
            callbacks.append(curr_callback)
    else:
        callbacks = None

    # Logging for trainer
    training_logger = None
    if cfg.logger is not None:
        for _, logger_cfg in cfg.logger.items():
            training_logger: pl.loggers.LightningLoggerBase = instantiate(
                logger_cfg, name=os.path.basename(os.getcwd())
            )
    trainer: pl.Trainer = instantiate(cfg.trainer, callbacks=callbacks, logger=training_logger)

    trainer.fit(model=network, datamodule=data_module, ckpt_path=cfg.get('checkpoint_path', None))


if __name__ == '__main__':
    train()  # pylint: disable=no-value-for-parameter
