# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.
# Local S2S adaptation
#   - added support for distributed inference
#   - modified reading of dataset to include index
#   - added scaling of predictions
#   - write forecasts directly to zarr store

import argparse
import contextlib
import logging
import os
from pathlib import Path

import dask.array
from hydra import initialize, compose
from hydra.utils import get_class, instantiate
import numpy as np
from omegaconf import open_dict
import pandas as pd
import torch
import torch.distributed as dist
from torch.utils.data import DistributedSampler
from tqdm import tqdm
import xarray as xr
import zarr

from poet.utils import configure_logging, get_model_checkpoint_path

logger = logging.getLogger(__name__)


def unscale_and_format_prediction(prediction, scaling_cfg):
    scaling_da = pd.DataFrame.from_dict(scaling_cfg, orient='index').to_xarray().astype('float32')
    scaling_std = scaling_da['std'].values[:, None, None]
    scaling_mean = scaling_da['mean'].values[:, None, None]
    prediction *= scaling_std
    prediction += scaling_mean
    for v, variable in enumerate(scaling_da['index'].values):
        if scaling_cfg[variable].get('log_epsilon', None) is not None:
            prediction[..., v, :, :] = np.exp(
                prediction[..., v, :, :] + np.log(scaling_cfg[variable]['log_epsilon'])
            ) - scaling_cfg[variable]['log_epsilon']
    return prediction


def inference(args: argparse.Namespace):
    # Set up torch distributed and select the proper device
    if torch.cuda.is_available():
        dist.init_process_group(backend='nccl', init_method='env://')
        device = torch.device(f'cuda:{dist.get_rank()}')
    else:
        device = torch.device('cpu')

    # Initialize Hydra and load the configuration
    overrides = getattr(args, 'overrides', [])
    with initialize(config_path=os.path.join(args.hydra_path, '.hydra'), version_base='1.1'):
        cfg = compose('config.yaml', overrides=overrides)
    logger.info(f"experiment working directory: {os.getcwd()}")
    if args.constants_path:
        constants_path = os.path.relpath(args.constants_path, cfg.data.directory)
        logger.info(f"Constants path: {args.constants_path}. Relative path: {constants_path}")
        new_constants = {}
        for key, value in cfg.data.constants.items():
            # new key is the name of the constant added to the constants path
            new_key = str(Path(constants_path) / Path(key).name)
            new_constants[new_key] = value
        with open_dict(cfg):
            cfg.data['constants'] = new_constants
    logger.debug(f"config: {cfg}")

    # Get model checkpoint
    model_name = args.model_name or Path(args.model_path).name
    model_checkpoint = get_model_checkpoint_path(args.model_path, args.model_version, args.checkpoint_name, model_name)
    if model_checkpoint is None:
        raise FileNotFoundError(
            f"model checkpoint not found in {args.model_path} for version {args.model_version} "
            f"and checkpoint name {args.checkpoint_name}"
        )
    logger.info(f"load model checkpoint {model_checkpoint}")
    model_class = get_class(cfg.model['_target_'])
    model = model_class.load_from_checkpoint(model_checkpoint, map_location=device)
    model = model.to(device)

    # Set up data module with overrides
    scaling_cfg = {v: cfg.data.scaling[v] for v in cfg.data.target_variables}
    data_module = instantiate(
        cfg.data.module,
        target_dataset_names=None,  # No target datasets needed for inference
        shuffle=False,
        splits=cfg.data.splits if args.use_splits else None,
        num_workers=4,
        batch_size=1,
        include_index=True,
    )
    data_module.setup()
    if dist.is_initialized():
        sampler = DistributedSampler(
            data_module.test_dataset,
            num_replicas=dist.get_world_size(),
            rank=dist.get_rank(),
            shuffle=False,
            drop_last=False
        )
        loader = data_module.test_dataloader(sampler=sampler)
    else:
        loader = data_module.test_dataloader()
    meta_ds = loader.dataset.ds

    dims = ['time', 'step', 'number', 'latitude', 'longitude']
    coords = {
        'time': meta_ds.time,
        'step': meta_ds.step,
        'number': list(range(cfg.data.ens_mems)),
        'latitude': meta_ds.latitude,
        'longitude': meta_ds.longitude
    }
    dim_sizes = [len(coords[dim]) for dim in dims]
    dummy_ds = xr.Dataset(coords=coords)
    for variable in cfg.data.target_variables:
        dummy_ds[variable] = xr.DataArray(
            dask.array.zeros(
                dim_sizes,
                dtype='float32',
                chunks=((1, 1) + tuple(dim_sizes[-3:]))
            ),
            dims=dims,
            coords=coords
        )
    # On rank 0, create the dataset. Otherwise, use torch dist to wait for the dataset to be created.
    # Make a call to to_zarr to create the dataset file store, unless resume_index is specified
    output_file = os.path.join(args.output_directory, args.output_file_name or f"model_{model_name}_forecast.zarr")
    if dist.is_initialized():
        if dist.get_rank() == 0 and not args.write_into_zarr:
            logger.info(f"creating output zarr dataset at {output_file}")
            dummy_ds.to_zarr(output_file, mode='w', compute=False)
        dist.barrier()
    elif not args.write_into_zarr:
        logger.info(f"creating output zarr dataset at {output_file}")
        dummy_ds.to_zarr(output_file, mode='w', compute=False)
    store = zarr.open(output_file, mode='a')

    # Precision casting
    if cfg.trainer.get('precision', 16) in [16, '16', '16-mixed'] and not args.full_precision:
        forward_context = torch.autocast(device_type='cuda', dtype=torch.float16)
    elif cfg.trainer.get('precision', 16) in ['bf16', 'bf16-mixed'] and not args.full_precision:
        forward_context = torch.autocast(device_type='cuda', dtype=torch.bfloat16)
    else:
        forward_context = contextlib.nullcontext()

    # Iterate over batches and make predictions. Use DistributedSampler to ensure each rank processes a unique
    # subset of the data.
    pbar = tqdm(range(len(loader)), smoothing=0.1)
    for _, batch in zip(pbar, loader):
        pbar.set_description(f"dataset index {batch[-1]}")
        t, s = loader.dataset.get_time_step_index(batch[-1])
        inputs = batch[0]
        inputs = inputs.to(device)
        with forward_context:
            outputs = model(inputs).detach().to(torch.float32).cpu().numpy()  # [b, number, c, latitude, longitude]
        # Re-scale outputs
        unscale_and_format_prediction(outputs, scaling_cfg)
        # Save to zarr store
        for v, variable in enumerate(cfg.data.target_variables):
            store[variable][t, s, :, :, :] = outputs[:, :, v]
        del outputs


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate predictions from a PoET model.')
    parser.add_argument('--model-path', type=str, required=True,
                        help="Path to model training outputs directory")
    parser.add_argument('--model-version', default=None, type=int,
                        help="Model version. Defaults to using the latest available version unless a specific integer"
                             " version number is specified.")
    parser.add_argument('--checkpoint-name', type=str, default='last.ckpt',
                        help="Model checkpoint file name")
    parser.add_argument('--model-name', type=str, default=None,
                        help="Name of the model. If not specified, the name will be derived from the model path.")
    parser.add_argument('--constants-path', type=str, default=None,
                        help="Path to input constants directory. Constructs a relative path from the data input "
                                "directory to the constants directory to override constants keys in config.")
    parser.add_argument('--overrides', nargs='+', default=[],
                        help="List of overrides for the config. Use these to, for example, update data paths (e.g., "
                             "`data.directory=new/path/to/data`) or lead times (data.input_lead_times).")
    parser.add_argument('--full-precision', action='store_true',
                        help="If set, uses full precision (float32) for inference. Otherwise, uses mixed precision "
                             "(float16) if used in trainer.")
    parser.add_argument('--use-splits', action='store_true',
                        help="Use test data split from model config")
    parser.add_argument('--output-directory', type=str, default='.',
                        help="Directory in which to save output forecast")
    parser.add_argument('--output-file-name', type=str, default=None,
                        help="Name of the output file to save the forecast. Defaults to "
                             "'model_{model_name}_forecast.zarr'.")
    parser.add_argument('--write-into-zarr', action='store_true',
                        help="If set, expects zarr output file to already exist and appends data to it.")

    configure_logging()

    run_args = parser.parse_args()
    # Hydra requires a relative (not absolute) path to working config directory. It also works in a sub-directory of
    # current python working directory.
    run_args.hydra_path = os.path.relpath(run_args.model_path, os.path.join(os.getcwd(), 'hydra'))
    logger.debug(f"model path: {run_args.model_path}")
    logger.debug(f"python working dir: {os.getcwd()}")
    logger.debug(f"hydra path: {run_args.hydra_path}")
    inference(run_args)
