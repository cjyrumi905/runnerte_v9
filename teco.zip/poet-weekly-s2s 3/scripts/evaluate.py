"""
Evaluate ensemble forecasts with a metric catalog.

Read metrics file. Iterate over sets of metrics for each matching the target variable.
Append all metrics from each metric set. If there are multiple with the same name, add
_{metric_set} to the name.
"""
from typing import Optional, Sequence, Union, Tuple
import logging
import argparse
from functools import reduce
import os
from pathlib import Path
import time

from dask.distributed import Client, LocalCluster
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xarray as xr

from evaluation.ensemble_metrics import CRPS, RankHistogram, EnsembleMeanSkill, \
     EnsembleSpreadSkillRatio, SpatialCRPS, SpatialEnsembleMeanSkill
from evaluation.utils import aggregate_forecast_weekly

try:
    import cartopy.crs as ccrs
    import cartopy.feature as cf
except ImportError:
    ccrs = cf = None

logger = logging.getLogger(__name__)
logging.getLogger('cfgrib').setLevel(logging.ERROR)
logging.getLogger('matplotlib').setLevel(logging.ERROR)
logging.getLogger('numcodecs').setLevel(logging.ERROR)
logging.getLogger('proj').setLevel(logging.ERROR)
logging.getLogger('pyproj').setLevel(logging.ERROR)


ALL_VARS = ['2m_temperature', 'scaled_total_precipitation', 'mean_sea_level_pressure']


def get_metrics_from_dict(metrics_type):
    non_spatial_metrics = {
        'emrms': EnsembleMeanSkill(),
        'rank_histogram': RankHistogram(),
        'essr': EnsembleSpreadSkillRatio(),
        'crps': CRPS(),
    }
    spatial_metrics = {
        'spatial_crps': SpatialCRPS(),
        'spatial_emrms': SpatialEnsembleMeanSkill()
    }
    if metrics_type == 'spatial':
        return spatial_metrics
    if metrics_type == 'non_spatial':
        return non_spatial_metrics
    return {**spatial_metrics, **non_spatial_metrics}


def compute_metric(metric, forecast, truth, lsm=None):
    metric_fn = metric
    return metric_fn.compute(forecast, truth, lsm=lsm)


def plot_map(ax, da, title=None, **kwargs):
    ax.set_global()
    c = ax.pcolormesh(da.longitude, da.latitude,
                      da.values, transform=ccrs.PlateCarree(),
                      **kwargs)
    plt.colorbar(c, ax=ax, shrink=0.7, orientation='horizontal', pad=0.05)
    ax.coastlines()
    ax.add_feature(cf.BORDERS, edgecolor=(0.5, 0.5, 0.5), linewidth=0.2)
    if title is not None:
        ax.set_title(title)


def rank_histo_plot(data, ax=None):
    plot_data = data.sel(model=list(data.coords['model'].values), step=data.step.values.max())
    if ax is None:
        fig, ax = plt.subplots()
        fig.set_size_inches(5, 4)
    for model in plot_data.coords['model'].values:
        model_data = plot_data.sel(model=model)
        try:
            model_data[~np.isnan(model_data)].plot(ax=ax, label=model)
        except TypeError:  # No data
            pass
    ax.set_title(plot_data.name)
    xmin, xmax = [-1, plot_data.bins.values.max() + 1]
    ax.hlines(1/(plot_data.bins.values.max() + 1), xmin, xmax, color='k', linewidth=1.5)
    ax.set_xlim(xmin, xmax)
    # ax.set_ylabel(f"units: {attrs.get('units', '')}")
    ax.set_ylabel("Observed Rank fraction")
    ax.set_xlabel("Rank")
    ax.legend(loc='best')
    ax.grid(True, linewidth=0.5, color=(0.3, 0.3, 0.3))
    plt.gcf().set_facecolor((0.9, 0.9, 0.9))


def plot(data, weekly=False, ax=None):
    plot_data = data.sel(model=list(data.coords['model'].values))
    if ax is None:
        fig, ax = plt.subplots()
        fig.set_size_inches(5, 4)
    for model in plot_data.model.values:
        model_data = plot_data.sel(model=model).assign_coords(
            step=plot_data.step.values if weekly else plot_data.step.values / np.timedelta64(1, 'D')
        )
        try:
            model_data[~np.isnan(model_data)].plot(ax=ax, label=model)
        except TypeError:  # No data
            pass
    ax.set_title(plot_data.name)
    ax.set_xlim(0, plot_data.step.values.max() + 1 if weekly else plot_data.step.values.max() / np.timedelta64(1, 'D'))
    # ax.set_ylabel(f"units: {attrs.get('units', '')}")
    ax.set_ylabel("Native units")
    ax.set_xlabel(f"Lead time ({'week' if weekly else 'day'})")
    ax.legend(loc='best')
    ax.grid(True, linewidth=0.5, color=(0.3, 0.3, 0.3))
    plt.gcf().set_facecolor((0.9, 0.9, 0.9))


def plot_all_map_metrics(forecast_metrics, metric_type, variable, output_directory=None):
    metrics = get_metrics_from_dict(metric_type)
    metrics_count = len(metrics.keys()) * len(forecast_metrics.step.values)
    ncols = 4
    # Calculate the number of rows (nrows) based on metric_count and ncols
    nrows = (metrics_count + ncols - 1) // ncols
    # Determine the figsize based on nrows and ncols
    figsize = (ncols * 4, nrows * 3)
    if ccrs is None:
        logger.warning("cartopy cannot be imported, skipping map plots")
        return
    for model in forecast_metrics.model.values:
        model_data = forecast_metrics.sel(model=model).assign_coords(
            step=forecast_metrics.step.values
        )
        # Create the subplots
        fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=figsize,
                                 subplot_kw={'projection': ccrs.Robinson()})
        ax_count = 0
        for (name, metric_data) in model_data.data_vars.items():
            for step in metric_data.step.values:
                plot_data = metric_data.sel(step=step)
                ax = axes.flatten()[ax_count]
                plot_map(ax, plot_data, title=f"{name}_{model}_step_{step}")
                ax_count += 1
        # create one legend:
        handles, labels = axes.flatten()[0].get_legend_handles_labels()
        plt.suptitle(f"{variable}_{model}")
        plt.tight_layout()
        fig.subplots_adjust(bottom=0.25 / nrows)
        fig.legend(handles, labels, loc='lower center', ncol=2 * ncols)
        if output_directory is not None:
            plt.savefig(output_directory / f"{variable}-{model}-All Spatial metrics.png")
            plt.savefig(output_directory / f"{variable}-{model}-All Spatial metrics.pdf")
        plt.show()
        plt.close()


def plot_all_metrics(forecast_metrics, metric_type, variable, output_directory, weekly=False):
    metrics = get_metrics_from_dict(metric_type)
    metrics_count = len(metrics.keys())
    ncols = 2
    # Calculate the number of rows (nrows) based on metric_count and ncols
    nrows = (metrics_count + ncols - 1) // ncols
    # Determine the figsize based on nrows and ncols
    figsize = (ncols * 4, nrows * 3)
    # Create the subplots
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=figsize)
    for ax, (name, metric_data) in zip(axes.flatten(), forecast_metrics.data_vars.items()):
        if name == 'rank_histogram':
            rank_histo_plot(metric_data, ax=ax)
            ax.legend().remove()
        else:
            plot(metric_data, weekly=weekly, ax=ax)
            ax.legend().remove()
    # create one legend:
    handles, labels = axes.flatten()[0].get_legend_handles_labels()
    plt.suptitle(variable)
    plt.tight_layout()
    fig.subplots_adjust(bottom=0.25 / nrows)
    fig.legend(handles, labels, loc='lower center', ncol=2 * ncols)
    plt.savefig(output_directory / f"{variable}-All metrics.png")
    plt.savefig(output_directory / f"{variable}-All metrics.pdf")
    plt.show()
    plt.close()


def _convert_time_step(dt):  # pylint: disable=invalid-name
    return pd.Timedelta(hours=dt) if isinstance(dt, int) else pd.Timedelta(dt)


def obs_to_verification(
        obs: Union[xr.Dataset, xr.DataArray],
        max_lead: Union[pd.Timedelta, int] = 168,
        steps: Optional[Sequence[pd.Timestamp]] = None,
        issue_times: Optional[Sequence[pd.Timestamp]] = None,
) -> Union[xr.Dataset, xr.DataArray]:
    """
    Convert a Dataset or DataArray of continuous time-series observations
    according to the obs data spec into the forecast data spec for direct
    comparison to forecasts.

    Parameters
    ----------
    obs: xarray Dataset or DataArray of observation data
    max_lead: maximum lead time for verification dataset. If int, interpreted
        as hours.
    steps: optional sequence of lead times to retain
    issue_times: issue times for the forecast result. If
        not specified, uses all available obs times.
    """
    issue_dim = 'time'
    lead_dim = 'step'
    max_lead = _convert_time_step(max_lead)
    if issue_times is None:
        issue_times = obs['time'].values
    obs_series = []
    for issue in issue_times:
        try:
            obs_series.append(
                obs.sel(**{'time': slice(issue, issue + max_lead)}).rename({'time': lead_dim})
            )
            obs_series[-1] = obs_series[-1].assign_coords(
                **{issue_dim: [issue], lead_dim: obs_series[-1][lead_dim] - issue})
        except Exception as e:  # pylint: disable=broad-exception-caught
            print(f'Failed to sel {issue} due to {e}')
            continue
    verification_ds = xr.concat(obs_series, dim=issue_dim)
    if steps is not None:
        verification_ds = verification_ds.sel(**{lead_dim: steps})

    return verification_ds


def get_weekly_steps(weeks):
    """
    Get a sequence of lead times for weekly forecasts. Default treatment for weekly forecasts is steps of 6 hours.

    :param weeks: number of weeks to forecast
    """
    return np.arange(pd.Timedelta('6H'), pd.Timedelta('7D') * weeks, pd.Timedelta('6H'))


def combine_forecast_and_obs(
        forecast: xr.Dataset,
        observation: xr.Dataset,
        variable: Optional[str] = '2m_temperature',
        interpolate_method: Optional[str] = None,
        weekly: Union[bool, str] = False,
        strict_lead_times: bool = True
) -> Tuple[xr.Dataset, xr.Dataset]:
    """
    Convert an observation dataset into a format suitable for direct comparison to a forecast, then compute
    the difference between forecast-observation.
    :param forecast: xarray Dataset of forecast data
    :param observation: xarray Dataset of observation data
    :param variable: str name of variable in forecast and observation
    :param interpolate_method: str method for interpolating forecast to observation grid
    :param weekly: if True, aggregate forecasts into weekly averages. If 'obs', aggregate obs only (assumes forecast
        is already weekly)
    :param strict_lead_times: if True, match exact lead times between forecast and observation, and omit any forecasts
        that have any missing lead times in observations.
    """
    required_dims = ['time', 'step', 'latitude', 'longitude', 'number']
    if any(d not in forecast.dims for d in required_dims):
        raise ValueError(f"forecast dataset missing one or more dimensions from {required_dims}: \n{forecast}")
    if variable not in observation.data_vars:
        raise ValueError(f"observation missing variable {variable}")
    if variable not in forecast.data_vars:
        raise ValueError(f"forecast missing variable {variable}")

    verification_steps = get_weekly_steps(int(forecast.step.max())) if weekly == 'obs' else \
        forecast.coords['step'].values
    max_lead = pd.Timedelta(days=7 * forecast.coords['step'].values.max()) if weekly == 'obs' else \
        pd.Timedelta(forecast.coords['step'].values.max())
    verification = obs_to_verification(
        observation[[variable]],
        max_lead=max_lead,
        issue_times=forecast.coords['time'].values,
        steps=verification_steps if strict_lead_times else None
    )
    if interpolate_method is not None:
        # Use scipy library; make sure to convert back to float32
        forecasted = forecast[[variable]].interp(
            number=forecast.number.values,
            latitude=observation.latitude,
            longitude=observation.longitude,
            method=interpolate_method
        ).astype('float32')
    else:
        # Small tolerance for round-off error
        forecasted = forecast[[variable]].sel(
            number=forecast.number.values,
            latitude=observation.latitude,
            longitude=observation.longitude,
            method='nearest',
            tolerance=1e-5
        )
    if weekly:
        verification = aggregate_forecast_weekly(verification, variable)
        if weekly != 'obs':
            forecasted = aggregate_forecast_weekly(forecasted, variable)
    return forecasted, verification

def _maybe_select_variable(ds, variable, log_epsilon=1e-3):
    if variable in ds.data_vars:
        ds = ds[[variable]]
    elif 'data' in ds.data_vars:
        ds = ds.sel(variable=variable)
        ds = ds.rename({'data': variable})
    elif f'scaled_{variable}' in ds.data_vars:
        logger.warning(f"variable '{variable}' found as 'scaled_{variable}'. Renaming to '{variable}' and "
                        f"applying scaling with log_epsilon={log_epsilon}")
        ds = ds[[f'scaled_{variable}']]
        ds = ds.rename({f'scaled_{variable}': variable})
        ds[variable] = np.exp( ds[variable] + np.log(log_epsilon)) - log_epsilon
    else:
        # Rename first variable to the variable name
        first_var_name = list(ds.data_vars.keys())[0]
        logger.warning(f"variable '{variable}' not found in dataset, using first variable '{first_var_name}'")
        ds = ds.rename({first_var_name: variable})
    for coord in ['isobaricInhPa', 'surface', 'valid_time']:
        if coord in ds.coords:
            ds = ds.drop(coord)
    return ds

def open_forecast(file, scale_factor=1., log_epsilon=1e-3, variable=None):
    files_split = str(file).split(',')
    if len(files_split) > 1:
        dss = []
        for member_file in files_split:
            dss.append(xr.open_zarr(member_file))
            try:
                dss[-1] = dss[-1].expand_dims('number')
            except ValueError:  # 'number' dimension already exists
                pass
        ds = xr.concat(dss, dim='number')
        ds = ds.assign_coords(number=np.arange(ds.dims['number']))
    else:
        ds = xr.open_zarr(file)
    ds = _maybe_select_variable(ds, variable or ALL_VARS[0], log_epsilon=log_epsilon)
    return ds * scale_factor if scale_factor != 1. else ds


def evaluate(args: argparse.Namespace) -> None:
    global ALL_VARS
    start_time = time.time()
    # Create output directory
    os.makedirs(args.output_directory, exist_ok=True)

    # Variable: if provided, run the evaluation for that variable only, else for all variables.
    if args.variable is None:
        args.variable = ALL_VARS
    else:
        ALL_VARS = [args.variable]
        args.variable = [args.variable]

    # Forecast names
    args.names = args.names[:len(args.forecasts)]
    if len(args.names) < len(args.forecasts):
        args.names += [f'model_{n}' for n in range(len(args.forecasts) - len(args.names))]

    # Scale factors
    if args.scale_factor is not None:
        if len(args.scale_factor) != len(args.forecasts):
            raise ValueError(f"scale factor length {len(args.scale_factor)} does not match number of forecasts "
                             f"{len(args.forecasts)}")
    else:
        args.scale_factor = [1.] * len(args.forecasts)

    # Set up Dask in multi-process mode
    if args.n_workers > 1:
        cluster = LocalCluster(n_workers=args.n_workers, threads_per_worker=1)
        _ = Client(cluster)
        logger.info(f"using Dask client with {args.n_workers} workers")

    def compute_forecast_metrics(forecast, truth, variable, metric_type, lsm=None):
        metrics = get_metrics_from_dict(metric_type)
        metrics_ds = []
        for name, metric in metrics.items():
            logger.info(f"adding {name}")
            try:
                temp_metric = compute_metric(metric, forecast, truth, lsm=lsm)
                logger.info(f"Completed calculation for {name}")
                metrics_ds.append(temp_metric.rename_vars({variable: name}))
            except BaseException as e:  # pylint: disable=broad-exception-caught
                logger.error(f"failed to compute metric {name}: {e}")
        return xr.combine_by_coords(metrics_ds)

    # Initialize Land-Sea Mask
    lsm = None
    if args.lsm_file is not None:
        lsm = xr.open_zarr(args.lsm_file)['land_sea_mask']

    for variable in args.variable:
        logger.info(f"evaluating metrics for variable '{variable}'")
        truth = _maybe_select_variable(xr.open_zarr(args.truth), variable)

        if args.match_issue_times:
            # To match issue times, we first need to open all forecasts
            logger.info(f"opening all forecasts: {args.forecasts}")
            forecasts = [open_forecast(f, s, args.log_epsilon, variable)
                         for f, s in zip(args.forecasts, args.scale_factor)]
            issue_times = reduce(np.intersect1d, [f.time.values for f in forecasts])
            issue_times.sort()
            logger.info(f"found {len(issue_times)} issue times: {issue_times}")
        else:
            forecasts = [None] * len(args.forecasts)
            logger.warning("inferring issue/lead times from first forecast because --match-issue-times is not set")
            first_forecast = open_forecast(args.forecasts[0], args.scale_factor[0], args.log_epsilon, variable)
            forecasts[0] = first_forecast
            issue_times = first_forecast.time.values

        # Iterate over forecasts
        forecast_metrics = {'spatial': [], 'non_spatial': []}
        for forecast_name, forecast_file, forecast, sf in zip(args.names, args.forecasts, forecasts, args.scale_factor):
            logger.info(f"computing metrics for forecast '{forecast_name}'")
            if forecast is None:
                logger.info(f"opening forecast for model '{forecast_name}' at '{forecast_file}'")
                forecast = open_forecast(forecast_file, sf, args.log_epsilon, variable)
            # Instead of trying to determine if a forecast is weekly, assume user provides consistent data.
            if args.lead_time is not None:
                forecast = forecast.sel(step=slice(None, pd.Timedelta(hours=args.lead_time)))
            if issue_times is not None:
                forecast = forecast.sel(time=issue_times)
            if args.step is not None:
                forecast = forecast.isel(time=slice(None, None, args.step))
            output_directory_v = Path(args.output_directory / variable)
            # Compute metrics dataset
            forecast, truth_series = combine_forecast_and_obs(forecast, truth, variable, args.interpolation)

            if args.metrics_type == 'all':
                metrics_type = ['non_spatial', 'spatial']
            else:
                metrics_type = [args.metrics_type]

            for metric_type in metrics_type:
                output_metrics_file = args.output_directory / variable / metric_type / f"metrics_{forecast_name}.zarr"
                if not args.redo_existing and output_metrics_file.exists():
                    logger.info(f"metrics file '{output_metrics_file}' already exists, reusing")
                    forecast_metrics[metric_type].append(xr.open_zarr(output_metrics_file).load())
                    continue

                logger.info(f"computing {metric_type} metrics")
                metrics_ds = compute_forecast_metrics(forecast, truth_series, variable, metric_type, lsm=lsm)
                metrics_ds = metrics_ds.assign_coords(model=forecast_name)

                # Compute after adding all metrics separately, to optimize dask graph
                metrics_ds = metrics_ds.compute()
                metrics_ds.to_zarr(output_metrics_file, mode='w')
                # Combine metrics
                forecast_metrics[metric_type].append(metrics_ds)

        # Plot metrics
        if not args.skip_plots:
            for metric_type in metrics_type:
                # Combine coords to align
                forecast_metrics[metric_type] = xr.concat(forecast_metrics[metric_type], dim='model', join='outer')
                if metric_type == 'spatial':
                    plot_all_map_metrics(forecast_metrics[metric_type], metric_type, variable, output_directory_v)
                else:
                    plot_all_metrics(forecast_metrics[metric_type], metric_type, variable, output_directory_v,
                                     weekly=args.weekly)

        logger.info("total evaluation time: %0.1f s", time.time() - start_time)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Evaluate ensemble forecasts.')
    parser.add_argument('-f', '--forecasts', type=Path, nargs='+', required=True,
                        help="Path to model forecast zarr files. If any element is comma-separated, we open "
                             "each of the forecasts as an ensemble member. Dimensions and variables must match.")
    parser.add_argument('-t', '--truth', type=Path, required=True,
                        help="Path to verification (truth) data without variable name")
    parser.add_argument('-o', '--output-directory', type=Path, required=True,
                        help="Directory in which to save output metrics.")
    parser.add_argument('-v', '--variable', type=str, default=None,
                        help="Name of variable in forecast and data to evaluate. If not provided, all variables "
                             "are evaluated")
    parser.add_argument('-n', '--names', type=str, nargs='+',
                        help="Names for each forecast file. If there aren't enough names, 'model_0' etc. will be "
                             "used as needed.")
    parser.add_argument('--scale-factor', nargs='+', type=float, default=None,
                        help="Scale factor for each forecast file. If not provided, no scaling is applied. "
                             "If provided, must match the number of forecast files.")
    parser.add_argument('--log-epsilon', type=float, default=1e-3,
                        help="Logarithmic epsilon value for scaling variables. Default is 1e-3.")
    parser.add_argument('--lead-time', type=int, default=None,
                        help="Restrict the maximum forecast lead time for evaluation to this many integer hours")
    parser.add_argument('--metrics-type', type=str, default='all',
                        help="Type of metrics to compute. Options are 'spatial', 'non_spatial', or 'all'.")
    parser.add_argument('--lsm-file', type=Path, default=None,
                        help="Path to land-sea mask file. If provided, will be used to mask out sea points in "
                             "metrics computation.")
    parser.add_argument('--weekly', action='store_true',
                        help="Evaluate weekly-averaged forecast values")
    parser.add_argument('--step', type=int, default=1,
                        help="Evaluate every 'step' forecasts")
    parser.add_argument('--match-issue-times', action='store_true',
                        help="Match issue times across all forecasts, for consistent measurements")
    parser.add_argument('--interpolation', type=str, default=None,
                        help="Interpolation method if needed (otherwise, matches forecast grid to truth grid)")
    parser.add_argument('--skip-plots', action='store_true',
                        help="Skip plotting step")
    parser.add_argument('--redo-existing', action='store_true',
                        help="Recompute metrics even if output file already exists")
    parser.add_argument('--n-workers', type=int, default=1,
                        help="Number of workers to use for dask cluster")

    run_args = parser.parse_args()

    evaluate(run_args)
