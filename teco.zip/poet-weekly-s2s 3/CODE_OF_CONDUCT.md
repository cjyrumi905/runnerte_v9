# Code of Conduct

Participants in this project are expected to communicate respectfully, welcome constructive feedback, and avoid harassment, discrimination, personal attacks, and disruptive behavior.

Project maintainers may remove comments, reject contributions, or restrict participation when conduct is inconsistent with these expectations. For conduct concerns, contact the repository maintainers through the private contact mechanism provided by the hosting platform.
