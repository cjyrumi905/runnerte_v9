import itertools as it
import logging
import os
import queue
import threading
import time
from functools import wraps

from AI_WQ_package import forecast_evaluation
from AI_WQ_package import forecast_submission
import numpy as np
import pandas as pd
from tqdm import tqdm
import xarray as xr


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
VARIABLES = ['tas', 'mslp', 'pr']
PERIODS = {
    '1': pd.Timedelta(days=18),
    '2': pd.Timedelta(days=25)
}


def retry_with_timeout(max_retries=3, timeout_seconds=30, backoff_factor=2, max_delay_seconds=10):
    """
    Decorator to retry functions with timeout and exponential backoff.

    Args:
        max_retries: Maximum number of retry attempts
        timeout_seconds: Timeout for each attempt in seconds
        backoff_factor: Multiplier for delay between retries
        max_delay_seconds: Maximum delay between retries in seconds
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):

            last_exception = None

            for attempt in range(max_retries + 1):
                try:
                    logger.info(f"Attempting {func.__name__} (attempt {attempt + 1}/{max_retries + 1})")

                    # Use threading to implement timeout
                    result_queue = queue.Queue()
                    exception_queue = queue.Queue()

                    def target():
                        try:
                            result = func(*args, **kwargs)
                            result_queue.put(result)  # pylint: disable=cell-var-from-loop
                        except Exception as e:    # pylint: disable=broad-exception-caught
                            exception_queue.put(e)  # pylint: disable=cell-var-from-loop

                    thread = threading.Thread(target=target)
                    thread.daemon = True
                    thread.start()
                    thread.join(timeout=timeout_seconds)

                    if thread.is_alive():
                        # Thread is still running, so we timed out
                        logger.warning(f"{func.__name__} timed out after {timeout_seconds} seconds")
                        raise TimeoutError(f"Function {func.__name__} timed out after {timeout_seconds} seconds")

                    # Check if an exception occurred
                    if not exception_queue.empty():
                        raise exception_queue.get()

                    # Get the result
                    if not result_queue.empty():
                        result = result_queue.get()
                        logger.info(f"{func.__name__} succeeded on attempt {attempt + 1}")
                        return result
                    raise RuntimeError(f"{func.__name__} completed but returned no result")

                except (Exception, TimeoutError) as e:  # pylint: disable=broad-exception-caught
                    last_exception = e
                    logger.warning(f"{func.__name__} failed on attempt {attempt + 1}: {str(e)}")

                    if attempt < max_retries:
                        delay = min(backoff_factor ** attempt, max_delay_seconds)
                        logger.info(f"Waiting {delay} seconds before retry...")
                        time.sleep(delay)
                    else:
                        logger.error(f"{func.__name__} failed after {max_retries + 1} attempts")
                        raise last_exception from e

            # This should never be reached, but just in case
            raise last_exception

        return wrapper
    return decorator


def ensemble_forecast_probs(forecast, climatology, verbose=False):
    """
    Compute ensemble forecast probabilities using conditional observation probabilities.
    
    Args:
        forecast: Forecast data with ensemble members
        climatology: Climatology data for comparison
        verbose: Whether to show progress bar
        
    Returns:
        Mean forecast probabilities across ensemble members
    """
    forecasts = []
    for _, number in enumerate(tqdm(forecast.number.values) if verbose else forecast.number.values):
        forecasts.append(
            forecast_evaluation.conditional_obs_probs(
                forecast.sel(number=number),
                climatology
            ).astype('float32')
        )
    nan_mask = np.isnan(forecasts[0])
    return xr.where(nan_mask, np.nan, xr.concat(forecasts, dim='number').mean('number'))


def upload_forecasts(forecast, climatology, passkey, team, model, max_retries=3, timeout_seconds=30):
    """Uploads the forecast to the AIWQ submission system."""

    # Create a single retry wrapper function that accepts any function
    def create_retry_wrapper(func):
        return retry_with_timeout(
            max_retries=max_retries,
            timeout_seconds=timeout_seconds
        )(func)

    # Create retry wrappers for each AI_WQ function
    create_empty_dataarray_with_retry = create_retry_wrapper(forecast_submission.AI_WQ_create_empty_dataarray)
    submit_forecast_with_retry = create_retry_wrapper(forecast_submission.AI_WQ_forecast_submission)
    check_submission_with_retry = create_retry_wrapper(forecast_submission.AI_WQ_check_submission)

    init_date = pd.Timestamp(forecast.time.values[0])
    for var, (period, lead_time) in it.product(VARIABLES, PERIODS.items()):
        logger.info("Compute forecast for %s, period %s", var, period)
        valid_time = init_date + lead_time
        forecast_to_submit = ensemble_forecast_probs(
            forecast[var].sel(time=init_date).sel(step=PERIODS[period]),
            climatology[var].sel(time=valid_time, method='nearest', tolerance='7D'),
            verbose=False
        ).compute()
        not_1 = xr.where(np.abs(forecast_to_submit.sum('quintile') - 1.) > 1e-3, True, False).astype(bool)
        if not_1.values.sum() > 0:
            logger.warning(f"replacing {int(not_1.values.sum())} non-compliant values with climatology")
            not_1 = xr.concat([not_1.expand_dims('quintile')] * 5, dim='quintile').assign_coords(
                quintile=forecast_to_submit.quintile)
            forecast_to_submit.values[not_1.values] = 0.2

        logger.info("Generating submission dataarray")
        submission_array = create_empty_dataarray_with_retry(
            var, init_date.strftime('%Y%m%d'), period, team, model, passkey
        )
        submission_array.values[:] = forecast_to_submit.values[:]

        logger.info("Submitting forecast with retry logic...")
        submitted_forecast = submit_forecast_with_retry(
            submission_array, var, init_date.strftime('%Y%m%d'), period, team, model, passkey
        )

        logger.info("Submitted %s", submitted_forecast)
        logger.info("Checking submission with retry logic...")
        check_submission_with_retry(var, init_date.strftime('%Y%m%d'), period, team, model, passkey)


def main(args):
    logger.info("Opening forecast at %s...", args.forecast_path)
    forecast = xr.open_zarr(args.forecast_path)
    logger.info("Opening climatology at %s...", args.climatology_path)
    climatology = xr.open_zarr(args.climatology_path)

    if 'scaled_pr' in forecast.data_vars and 'pr' not in forecast.data_vars:
        forecast['pr'] = np.exp(forecast['scaled_pr'] + np.log(args.log_epsilon)) - args.log_epsilon

    upload_forecasts(
        forecast,
        climatology,
        args.passkey,
        args.team,
        args.model,
        args.max_retries,
        args.timeout_seconds
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Upload AIWQ forecasts")
    parser.add_argument('--forecast-directory', type=str, required=True,
                        help="Directory containing the forecast zarr store")
    parser.add_argument('--forecast-name', type=str, default='forecast.zarr',
                        help="Name of the forecast zarr store")
    parser.add_argument('--climatology-path', type=str, required=True,
                        help="Path to the climatology zarr store")
    parser.add_argument('--passkey', type=str, required=True,
                        help="Passkey for AIWQ submission")
    parser.add_argument('--team', type=str, required=True,
                        help="Team name for submission")
    parser.add_argument('--model', type=str, required=True,
                        help="Model name for submission")
    parser.add_argument('--log-epsilon', type=float, default=1.0,
                        help="Log epsilon value for scaling precipitation")
    parser.add_argument('--max-retries', type=int, default=10,
                        help="Maximum number of retry attempts for FTP operations")
    parser.add_argument('--timeout-seconds', type=int, default=30,
                        help="Timeout in seconds for each FTP operation attempt")

    run_args = parser.parse_args()

    # Construct forecast path
    run_args.forecast_path = os.path.join(run_args.forecast_directory, run_args.forecast_name)

    main(run_args)
