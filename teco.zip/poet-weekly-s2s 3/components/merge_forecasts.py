#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Combine multiple zarr stores from different directories into a single zarr store.
"""

import argparse
import os
import shutil
import logging

import xarray as xr

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def combine_zarr_stores(input_dirs, output_dir, output_name):
    """
    Combine multiple zarr stores from different directories into a single zarr store.
    
    Args:
        input_dirs: List of directories containing zarr stores
        output_dir: Output directory for the combined zarr store
        output_name: Base name for the zarr stores (both input and output)
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    output_zarr_path = os.path.join(output_dir, f"{output_name}.zarr")

    # Check if any input dirs are valid
    valid_dirs = [d for d in input_dirs if os.path.exists(os.path.join(d, f"{output_name}.zarr"))]

    if not valid_dirs:
        raise FileNotFoundError("No valid input zarr stores found")

    # First, copy the first store to the output location
    first_zarr_path = os.path.join(valid_dirs[0], f"{output_name}.zarr")
    logger.info(f"Copying first zarr store from {first_zarr_path} to {output_zarr_path}")

    if os.path.exists(output_zarr_path):
        shutil.rmtree(output_zarr_path)
    shutil.copytree(first_zarr_path, output_zarr_path)

    # For each subsequent store, append it to the output
    for idx, input_dir in enumerate(valid_dirs[1:], start=1):
        input_zarr_path = os.path.join(input_dir, f"{output_name}.zarr")
        logger.info(f"Appending zarr store {idx} from {input_zarr_path}")

        # Open the input store
        input_ds = xr.open_zarr(input_zarr_path)

        # Write
        input_ds.to_zarr(output_zarr_path, mode='a')

    logger.info(f"Successfully combined {len(valid_dirs)} zarr stores into {output_zarr_path}")


def main(args):
    """Main function."""
    try:
        combine_zarr_stores(
            args.input_dirs,
            args.output_dir,
            args.output_name
        )
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Combine multiple zarr stores from different directories into a single zarr store."
    )
    parser.add_argument(
        "--input-dirs",
        type=str,
        nargs="+",
        required=True,
        help="List of input directories containing zarr stores",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        required=True,
        help="Output directory for the combined zarr store",
    )
    parser.add_argument(
        "--output-name",
        type=str,
        required=True,
        help="Base name for the zarr stores (both input and output)",
    )

    run_args = parser.parse_args()
    main(run_args)
