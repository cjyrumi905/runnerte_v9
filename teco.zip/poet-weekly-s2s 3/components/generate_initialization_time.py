# Licensed under the MIT License.
"""
Generates a YAML file containing the forecast initialization time. Used for operational forecasting pipeline.
"""

import argparse
import os

import pandas as pd
import yaml


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate dates for unified data updates.')
    parser.add_argument('--output-directory', type=str, default='.',
                        help='Directory to save the YAML file ("initialization_time.yaml").')
    parser.add_argument('--initialization-time', type=pd.Timestamp, default=None,
                        help='Initialization time in pandas-interpretable format. Defaults to the current UTC time.')
    parser.add_argument('--default-time-offset', type=pd.Timedelta, default=pd.Timedelta('0h'),
                        help='If a specific initialization time is not provided, use this offset from now.')
    parser.add_argument('--time-floor', type=pd.Timedelta, default=pd.Timedelta('24h'),
                        help='Round the initialization time down to this interval, if specific time is not provided.')

    args = parser.parse_args()

    # Get times if not provided
    if args.initialization_time is None:
        args.initialization_time = pd.Timestamp.utcnow().tz_localize(None) - args.default_time_offset
        args.initialization_time = args.initialization_time.floor(args.time_floor)
    assert args.initialization_time < pd.Timestamp.utcnow().tz_localize(None), \
        "Initialization time must be less than current time."

    # Generate yaml file
    with open(os.path.join(args.output_directory, 'times.yaml'), 'w') as f:
        yaml.dump({
            'initialization_time': str(args.initialization_time)
        }, f)
    print(f"Generated initialization_time.yaml with initialization_time: {args.initialization_time}")
