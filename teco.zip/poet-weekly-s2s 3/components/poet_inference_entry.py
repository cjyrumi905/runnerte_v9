# Licensed under the MIT License.
"""
Wrapper for the inference script to be used in the POET inference entry point.
"""

import argparse
import logging
import os
from pathlib import Path
import sys

from components.common import str_to_bool

# Add the parent directory to sys.path to import the inference_poet module
sys.path.append(str(Path(__file__).parent.parent))
from scripts.inference_poet import inference, configure_logging  # pylint: disable=wrong-import-position

logger = logging.getLogger(__name__)


def main(args):
    """Main entry point for the AML component."""
    # Make sure output directory exists
    os.makedirs(args.output_directory, exist_ok=True)

    # Update overrides
    args.overrides.append('data.directory=' + args.input_data_path)
    args.overrides.append('data.dataset_names=[s2s_forecast]')

    # Other args to match
    model_name = args.model_name or Path(args.model_path).name
    output_file = os.path.join(args.output_directory, f"model_{model_name}_forecast.zarr")
    args.write_into_zarr = Path(output_file).exists() and args.write_into_zarr
    args.use_splits = False

    # Call inference function from inference_poet.py
    inference(args)

    logger.info("Inference complete")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate predictions from a PoET model.')
    parser.add_argument('--model-path', type=str, required=True,
                        help="Path to model training outputs directory")
    parser.add_argument('--model-version', default=None, type=int,
                        help="Model version. Defaults to using the latest available version unless a specific integer"
                             " version number is specified.")
    parser.add_argument('--checkpoint-name', type=str, default='last.ckpt',
                        help="Model checkpoint file name")
    parser.add_argument('--model-name', type=str, default=None,
                        help="Name of the model. If not specified, the name will be derived from the model path.")
    parser.add_argument('--input-data-path', type=str, required=True,
                        help="Path to input data directory.")
    parser.add_argument('--constants-path', type=str, default=None,
                        help="Path to input constants directory.")
    parser.add_argument('--overrides', nargs='+', default=[],
                        help="List of overrides for the Hydra config. The following are overridden by this entry code "
                             "and should NOT be included:\n"
                             "  - `data.directory` (use `--input-data-path` instead),\n"
                             "  - `data.dataset_names` (set to '[s2s_forecast]').")
    parser.add_argument('--full-precision', type=str_to_bool, default=False,
                        help="If set, uses full precision (float32) for inference. Otherwise, uses mixed precision "
                             "(float16) if used in trainer.")
    parser.add_argument('--output-directory', type=str, default='.',
                        help="Directory in which to save output forecast")
    parser.add_argument('--output-file-name', type=str, default='forecast.zarr',
                        help="Name of the output file to save the forecast.")

    run_args = parser.parse_args()

    # Configure logging
    configure_logging()

    # Hydra requires a relative (not absolute) path to working config directory. It also works in a sub-directory of
    # current python working directory.
    run_args.hydra_path = os.path.relpath(run_args.model_path, os.path.join(os.getcwd(), 'hydra'))
    logger.debug(f"model path: {run_args.model_path}")
    logger.debug(f"python working dir: {os.getcwd()}")
    logger.debug(f"hydra path: {run_args.hydra_path}")
    logger.info(f"output directory: {run_args.output_directory}")

    main(run_args)
