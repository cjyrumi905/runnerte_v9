# Licensed under the MIT License.
"""
Common utilities for the components.
"""

import argparse


def str_to_bool(value):
    """Convert a string representation to a boolean value.
    
    Args:
        value: String or boolean to convert
        
    Returns:
        bool: True for "true", "yes", "y", "1", True. False otherwise.
    """
    if isinstance(value, bool):
        return value
    if value.lower() in ('true', 'yes', 'y', '1'):
        return True
    if value.lower() in ('false', 'no', 'n', '0'):
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {value}")
