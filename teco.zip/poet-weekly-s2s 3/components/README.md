# Pipeline components

This directory contains Python entry points used by the data and forecast workflows. The former provider-specific component manifests have been removed because their schemas and container image references were tied to one execution service and were not portable.

Run the corresponding Python entry points directly or define equivalent tasks in your scheduler/orchestrator:

- `download_s2s_forecasts_entry.py` — retrieve S2S forecast and hindcast inputs.
- `format_s2s_forecasts.py` — format downloaded forecast data.
- `generate_initialization_time.py` — create initialization-time metadata.
- `merge_forecasts.py` — merge forecast stores.
- `poet_inference_entry.py` — execute POET inference.

The workflows require access to the configured S2S input data, hindcast years, verification data where applicable, static constants, model checkpoints, configuration files, and writable output storage. See the repository README and the individual command-line `--help` output for arguments.
