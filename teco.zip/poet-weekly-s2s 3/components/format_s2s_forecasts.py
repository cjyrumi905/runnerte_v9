# Licensed under the MIT License.
"""
Wrapper script that calls hindcast_data.py to format S2S forecasts for a single 
initialization time read from a YAML file.
"""

import argparse
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd
from ruamel.yaml import YAML

from components.common import str_to_bool

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main(args):
    # Read initialization time from YAML file
    yaml_path = args.initialization_time_path / 'times.yaml'
    if not yaml_path.exists():
        raise FileNotFoundError(f"YAML file not found: {yaml_path}")

    try:
        yaml_parser = YAML()
        with open(yaml_path, 'r') as f:
            time_data = yaml_parser.load(f)

        initialization_time = time_data.get('initialization_time')
        if not initialization_time:
            raise ValueError(f"No initialization_time found in {yaml_path}")

        initialization_time = pd.Timestamp(initialization_time)
        logger.info(f"Using initialization time: {initialization_time}")

        # Validate initialization time
        assert initialization_time < pd.Timestamp.utcnow().tz_localize(None), \
            "Initialization time must be less than current time."

        # Create a temporary config file with the updated directory
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as tmp_config:
            # Load the original config
            yaml_parser.preserve_quotes = True
            with open(args.config_path, 'r') as f:
                config = yaml_parser.load(f)

            # Update the directory path
            config['directory'] = args.data_directory

            # Save to the temporary file
            yaml_parser.dump(config, tmp_config)
            temp_config_path = tmp_config.name

        # Construct the base common arguments for both create and write operations
        base_args = [
            "--path", str(Path(args.output_path) / 's2s_forecast.zarr'),
            "--config-path", temp_config_path,
            "--start-time", str(initialization_time),
            "--end-time", str(initialization_time),
            "--frequency", "1D",
            "--hindcast-years", "0",
        ]

        # Create command with subcommand first
        create_cmd = [
            sys.executable,
            "-m", "data_pipelines.hindcast_data",
            "create"  # Subcommand first
        ] + base_args + [
            "--step-slice", args.step_slice,
            "--resolution", str(args.resolution),
            "--members", str(args.members),
        ]

        if args.chunk_members:
            create_cmd.append("--chunk-members")

        # Write command with subcommand first
        write_cmd = [
            sys.executable,
            "-m", "data_pipelines.hindcast_data",
            "write"  # Subcommand first
        ] + base_args + [
            "--num-workers", str(args.num_workers),
            "--num-processes", str(args.num_processes),
        ]

        if args.verbose:
            write_cmd.append("--verbose")

        if args.disable_resume:
            write_cmd.append("--disable-resume")

        # Execute the create command
        logger.info(f"Executing create command: {' '.join(create_cmd)}")
        subprocess.run(create_cmd, check=True)

        # Execute the write command
        logger.info(f"Executing write command: {' '.join(write_cmd)}")
        subprocess.run(write_cmd, check=True)

        logger.info(f"Successfully processed hindcast data for initialization time: {initialization_time}")

    except Exception as e:
        logger.error(f"Error processing request: {e}")
        raise
    finally:
        # Clean up the temporary config file
        if 'temp_config_path' in locals() and os.path.exists(temp_config_path):
            os.unlink(temp_config_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Wrapper script for hindcast_data.py "
                                     "that formats S2S forecasts for a single initialization time")
    parser.add_argument("--initialization-time-path", type=Path, required=True,
                        help="Path containing YAML file (times.yaml)")
    parser.add_argument("--output-path", type=str, required=True,
                        help="Path where the hindcast data should be stored")
    parser.add_argument("--data-directory", type=str, required=True,
                        help="Path to the directory containing the source data")
    parser.add_argument("--config-path", type=str,
                        default=os.path.join('data_pipelines', 'configs', 'ecmwf_s2s_forecast.yaml'),
                        help="Path to the config file for hindcast_data.py")
    parser.add_argument("--step-slice", type=str, default='1d:45d:1d',
                        help="Slice for the step (lead time) dimension")
    parser.add_argument("--resolution", type=float, default=1.5,
                        help="Latitude/longitude resolution of the data")
    parser.add_argument("--members", type=int, default=100,
                        help="Number of ensemble members")
    parser.add_argument("--chunk-members", type=str_to_bool, default='False',
                        help="Option to chunk each ensemble member (True/False)")
    parser.add_argument("--num-workers", type=int, default=1,
                        help="Number of workers for the write command")
    parser.add_argument("--num-processes", type=int, default=1,
                        help="Number of processes to use on each worker")
    parser.add_argument("--verbose", type=str_to_bool, default='False',
                        help="Enable verbose logging (True/False)")
    parser.add_argument("--disable-resume", type=str_to_bool, default='False',
                        help="Disable resuming from previous run (True/False)")

    run_args = parser.parse_args()
    main(run_args)
