# Support

For questions about setup, configuration, training, or inference, open an issue in the repository with:

- the operating system and Python version;
- the relevant configuration file and command (with secrets removed);
- the complete error traceback;
- a concise description of the expected and observed behavior.

Questions about upstream POET architecture should also consult the official ECMWF-Lab POET repository linked in `UPSTREAM_ATTRIBUTION.md`.
