# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.
# Local S2S adaptation
#   - Remove unnecessary components

import logging
from typing import Optional, Union, Sequence, DefaultDict

import pytorch_lightning as pl
from torch.utils.data import DataLoader

from .data_loading import open_verified_ensemble_dataset, IndexedVerifiedEnsembleDataset, VerifiedEnsembleDataset


logger = logging.getLogger(__name__)



class VerifiedEnsembleDataModule(pl.LightningDataModule):
    def __init__(
            self,
            directory: str = '.',
            dataset_names: Sequence[str] = (),
            target_dataset_names: Optional[Sequence[str]] = None,
            batch_size: int = 32,
            drop_last: bool = False,
            input_variables: Optional[Sequence[str]] = None,
            sample_lead_times: Sequence[int] = (),
            target_variables: Optional[Sequence[str]] = None,
            constants: Optional[dict[str, str]] = None,
            shuffle: bool = True,
            scaling: Optional[dict[str, dict[str, float]]] = None,
            splits: Optional[DefaultDict] = None,
            subsample_size: Union[int, Sequence, None] = None,
            add_lead_time: bool = False,
            insolation_type: Optional[str] = None,
            grid_dims: Sequence[int] = (32, 64),
            target_clipping: Union[float, Sequence[float], None] = None,
            check_nans: bool = True,
            fill_nans_in_input: bool = False,
            num_workers: int = 4,
            pin_memory: bool = True,
            include_index: bool = False,
    ):
        super().__init__()
        self.directory = directory
        self.dataset_names = dataset_names
        self.target_dataset_names = target_dataset_names
        self.batch_size = batch_size
        self.drop_last = drop_last
        self.input_variables = input_variables
        self.sample_lead_times = sample_lead_times
        self.target_variables = target_variables
        self.constants = constants
        self.shuffle = shuffle
        self.scaling = scaling
        self.splits = splits
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.subsample_size = subsample_size
        self.add_lead_time = add_lead_time
        self.insolation_type = insolation_type
        self.grid_dims = grid_dims
        self.check_nans = check_nans
        self.fill_nans_in_input = fill_nans_in_input
        self.target_clipping = target_clipping
        self.include_index = include_index

        self.train_dataset = None
        self.val_dataset = None
        self.test_dataset = None

    def setup(self, stage: Optional[str] = None) -> None:  # pylint: disable=unused-argument
        dataset = open_verified_ensemble_dataset(
            directory=self.directory,
            dataset_names=self.dataset_names,
            input_variables=self.input_variables,
            sample_lead_times=self.sample_lead_times,
            target_dataset_names=self.target_dataset_names,
            target_variables=self.target_variables,
            constants=self.constants,
            scaling=self.scaling
        )
        dataset = dataset.isel(latitude=slice(None, self.grid_dims[0]),
                               longitude=slice(None, self.grid_dims[1]))
        dataset_class = IndexedVerifiedEnsembleDataset if self.include_index else VerifiedEnsembleDataset
        if self.splits is not None:
            self.train_dataset = dataset_class(
                dataset=dataset.sel(time=slice(self.splits['train_date_start'], self.splits['train_date_end'])),
                scaling=self.scaling,
                shuffle=self.shuffle,
                subsample_size=self.subsample_size,
                batch_size=self.batch_size,
                drop_last=self.drop_last,
                add_lead_time=self.add_lead_time,
                insolation_type=self.insolation_type,
                check_nans=self.check_nans,
                fill_nans_in_input=self.fill_nans_in_input,
                target_clipping=self.target_clipping
            )
            self.val_dataset = dataset_class(
                dataset=dataset.sel(time=slice(self.splits['val_date_start'], self.splits['val_date_end'])),
                scaling=self.scaling,
                shuffle=False,
                subsample_size=self.subsample_size,
                batch_size=self.batch_size,
                add_lead_time=self.add_lead_time,
                insolation_type=self.insolation_type,
                check_nans=self.check_nans,
                fill_nans_in_input=self.fill_nans_in_input,
                target_clipping=self.target_clipping
            )
            self.test_dataset = dataset_class(
                dataset=dataset.sel(time=slice(self.splits['test_date_start'], self.splits['test_date_end'])),
                scaling=self.scaling,
                shuffle=False,
                subsample_size=self.subsample_size,
                batch_size=self.batch_size,
                add_lead_time=self.add_lead_time,
                insolation_type=self.insolation_type,
                check_nans=self.check_nans,
                fill_nans_in_input=self.fill_nans_in_input,
                target_clipping=self.target_clipping
            )
        else:
            self.test_dataset = dataset_class(
                dataset=dataset,
                scaling=self.scaling,
                shuffle=False,
                subsample_size=self.subsample_size,
                batch_size=self.batch_size,
                add_lead_time=self.add_lead_time,
                insolation_type=self.insolation_type,
                check_nans=self.check_nans,
                fill_nans_in_input=self.fill_nans_in_input,
                target_clipping=self.target_clipping
            )

    def train_dataloader(self, **kwargs) -> DataLoader:
        return DataLoader(
            dataset=self.train_dataset,
            pin_memory=self.pin_memory,
            num_workers=self.num_workers,
            shuffle=self.shuffle,
            batch_size=None,
            **kwargs
        )

    def val_dataloader(self, **kwargs) -> DataLoader:
        return DataLoader(
            dataset=self.val_dataset,
            pin_memory=self.pin_memory,
            num_workers=self.num_workers,
            batch_size=None,
            **kwargs
        )

    def test_dataloader(self, **kwargs) -> DataLoader:
        return DataLoader(
            dataset=self.test_dataset,
            pin_memory=self.pin_memory,
            num_workers=self.num_workers,
            batch_size=None,
            **kwargs
        )
