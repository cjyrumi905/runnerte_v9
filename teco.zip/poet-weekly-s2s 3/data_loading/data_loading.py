# Copyright (c) European Centre for Medium-Range Weather Forecasts.
# Licensed under the MIT License.
# Local S2S adaptation
#  - Remove unnecessary components
#  - Add docstrings and type hints
#  - Add support for multiple target variables
#  - Add IndexedVerifiedEnsembleDataset

from collections.abc import Iterable
import logging
import os
from pathlib import Path
import time
from typing import Any, Optional, Sequence, Union

import dask.array as darray
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
import xarray as xr

from poet.utils import insolation

logger = logging.getLogger(__name__)


def _get_variable_sel_slice(ds, variables, coord_name='variable'):
    """
    Get a slice object for the given variables if they are contiguous in the dataset.
    Otherwise, return the list of variables.
    """
    sliced_variables = ds.sel(**{coord_name: slice(variables[0], variables[-1])})[coord_name].values
    if len(variables) == len(sliced_variables) and all(v == w for v, w in zip(variables, sliced_variables)):
        return slice(list(variables)[0], list(variables)[-1])
    return list(variables)


def open_verified_ensemble_dataset(
    directory: str,
    dataset_names: Sequence[str],
    input_variables: list[str],
    sample_lead_times: Union[list[int], str],
    target_dataset_names: Optional[Sequence[str]] = None,
    target_variables: Optional[Sequence[str]] = None,
    constants: Union[dict[str, str], None] = None,
    scaling: Union[dict[str, dict[str, float]], None] = None
) -> xr.Dataset:
    """
    Opens and processes ensemble datasets for weather forecasting, combining input, target, and constant data 
    into a single xarray.Dataset.
    Parameters:
        directory (str): Path to the directory containing the dataset files.
        dataset_names (Sequence[str]): List of names of the input datasets to load.
        input_variables (list[str]): List of input variable names to extract from the datasets.
        sample_lead_times (list[int] or str): List of lead times in integer hours to sample from the datasets,
            or a colon-separated string specifying the lead time range (e.g., "0:168:24").
        target_dataset_names (Optional[Sequence[str]]): List of names of the target datasets to load.
        target_variables (Optional[Sequence[str]]): List of target variable names to extract.
        constants (Union[dict[str, str], None]): Dictionary mapping constant dataset names to variable names.
        scaling (Union[dict[str, dict[str, float]], None]): Dictionary specifying scaling parameters for variables. 
            If a variable has a 'log_epsilon' key, log scaling will be applied.
    Returns:
        xr.Dataset: A dataset containing the processed inputs, targets, and constants.
    Raises:
        NotImplementedError: If log scaling is specified in the scaling dictionary, as it is not yet implemented.
        AssertionError: If the input datasets do not have the required dimensions.
    Notes:
        - Input datasets must have the following dimensions: 'latitude', 'longitude', 'number', 'time', 'step', 
          and 'variable'.
        - Target datasets must have the 'time' dimension, which is renamed to 'obs_time'.
        - If no target datasets are specified, a target array of zeros is generated.
        - Constants are merged into a single array with a 'channel_c' dimension.
        - Log scaling is currently not implemented and will raise a NotImplementedError if specified.
    """
    scaling = scaling or {}
    merge_time = time.time()

    datasets = []
    for name in dataset_names:
        file_name = Path(directory) / f"{name}.zarr"
        logger.debug(f"open zarr dataset {file_name}")
        ds = xr.open_zarr(file_name, chunks={})
        assert 'data' in ds.data_vars, "dataset must have a 'data' variable"
        assert all(d in ds.dims for d in ['latitude', 'longitude', 'number', 'time', 'step', 'variable']), \
            "dataset must have 'latitude', 'longitude', 'number', 'time', 'step', and 'variable' dimensions"
        # TODO: Apply log scaling lazily.  # pylint: disable=fixme
        # For any variable in the dataset, check if it is in the scaling dict and has a log_epsilon value
        # If so, apply the log scaling to the variable. Do this in an intelligent way that applies an Identity
        # transform to any non-log-scaled variables but does the log scaling to the log-scaled variables.
        datasets.append(ds.rename({'variable': 'channel_in'}))
    # Concatenate variables
    input_ds = xr.concat(datasets, dim='channel_in')
    # Select desired input variables
    if input_variables is not None:
        input_ds = input_ds.sel(channel_in=_get_variable_sel_slice(input_ds, input_variables, 'channel_in'))
    else:
        input_variables = list(input_ds.channel_in.values)
    # Select desired lead times
    if sample_lead_times is not None:
        if isinstance(sample_lead_times, str):
            step_slice = sample_lead_times.split(':')
            step_slice = [pd.Timedelta(hours=int(step)) for step in step_slice[:2]] + [int(d) for d in step_slice[2:]]
            input_ds = input_ds.sel(step=slice(*step_slice))
        else:
            input_ds = input_ds.sel(step=[pd.Timedelta(hours=int(step)) for step in sample_lead_times])
    # If 'time' dim is not sorted, sort it
    if not pd.Series(input_ds.time).is_monotonic_increasing:
        input_ds = input_ds.sortby('time')
    # Convert to a single input/target array
    input_da = input_ds.data.rename('inputs').transpose(
        'time', 'step', 'number', 'channel_in', 'latitude', 'longitude')

    # Get the target, if specified. If not specified, generate zeros
    if target_dataset_names is not None:
        targets = []
        for name in target_dataset_names:
            file_name = Path(directory) / f"{name}.zarr"
            logger.debug(f"open target file {file_name}")
            target_ds = xr.open_zarr(file_name, chunks={})
            assert 'data' in target_ds.data_vars, "dataset must have a 'data' variable"
            assert all(d in target_ds.dims for d in ['latitude', 'longitude', 'time', 'variable']), \
                "dataset must have 'latitude', 'longitude', 'time', and 'variable' dimensions"
            try:
                target_ds = target_ds.drop('valid_time')
            except ValueError:
                pass
            targets.append(target_ds.rename({'time': 'obs_time', 'variable': 'channel_out'}))
        target_ds = xr.concat(targets, dim='channel_out')
        # Select desired target variables
        if target_variables is not None:
            target_ds = target_ds.sel(channel_out=_get_variable_sel_slice(target_ds, target_variables, 'channel_out'))
        else:
            target_variables = list(target_ds.channel_out.values)
        target_da = target_ds.data.rename('targets').transpose(
            'obs_time', 'channel_out', 'latitude', 'longitude')
    else:
        logger.info("no target variable selected; generating zeros")
        expected_obs_times = pd.Series((input_ds.time + input_ds.step).values.flatten()).unique()
        target_da = xr.DataArray(
            darray.zeros((len(expected_obs_times), 1, input_ds.sizes['latitude'], input_ds.sizes['longitude']),
                         dtype='float32', chunks=(-1, 1, -1, -1)),
            dims=('obs_time', 'channel_out', 'latitude', 'longitude'),
            coords={
            'obs_time': expected_obs_times,
            'channel_out': ['zeros'],
            'latitude': input_ds.latitude,
            'longitude': input_ds.longitude
            }
        )

    # TODO: Implement log scaling. Check log scaling compatibility for now   # pylint: disable=fixme
    for variable in input_variables + (target_variables or []):
        if variable in scaling and scaling[variable].get('log_epsilon', None) is not None:
            raise NotImplementedError(f"log scaling not implemented yet. Found 'log_epsilon' for {variable} "
                                      f"in scaling dict")

    result = xr.Dataset()
    result['inputs'] = input_da
    result['targets'] = target_da

    # Get constants
    if constants is not None:
        constants_ds = []
        for name, var in constants.items():
            constants_ds.append(xr.open_zarr(os.path.join(directory, f"{name}.zarr"))[var])
        constants_ds = xr.merge(constants_ds)
        constants_da = constants_ds.to_array('channel_c', name='constants').transpose(
            'channel_c', 'latitude', 'longitude')
        result['constants'] = constants_da

    logger.info(f"merged datasets in {time.time() - merge_time:0.1f} s")

    return result


class VerifiedEnsembleDataset(Dataset):
    def __init__(
            self,
            dataset: xr.Dataset,
            scaling: dict,
            shuffle: bool = True,
            return_da: bool = False,
            subsample_size: Union[int, Sequence, None] = None,
            batch_size: int = 32,
            drop_last: bool = False,
            add_lead_time: bool = False,
            insolation_type: Optional[str] = None,
            check_nans: bool = True,
            fill_nans_in_input: bool = False,
            target_clipping: Union[float, Sequence[float], None] = None
    ):
        self.ds = dataset
        self.scaling = scaling
        self.shuffle = shuffle
        self.return_da = return_da
        self.subsample_size = subsample_size
        self.batch_size = batch_size
        self.drop_last = drop_last
        self.add_lead_time = add_lead_time
        self.insolation_type = insolation_type
        self.check_nans = check_nans
        self.fill_nans_in_input = fill_nans_in_input
        if target_clipping is None:
            self.target_clipping = None
        else:
            self.target_clipping = target_clipping if isinstance(target_clipping, Iterable) else (target_clipping, None)

        if self.drop_last:
            self._time_dim = self.ds.sizes['time'] // batch_size
        else:
            self._time_dim = int(np.ceil(self.ds.sizes['time'] / batch_size))
        self._step_dim = self.ds.sizes['step']

        self.add_insolation = insolation_type is not None
        if self.add_insolation:
            if insolation_type not in ['daily', 'instantaneous']:
                raise ValueError(f"insolation_type must be 'daily' or 'instantaneous', not {insolation_type}")
        self.has_metadata = self.add_insolation or self.add_lead_time
        self._input_scaling = None
        self._target_scaling = None
        self._get_scaling_da()

    def _get_scaling_da(self):
        scaling_df = pd.DataFrame.from_dict(self.scaling).T
        scaling_df.loc['zeros'] = {'mean': 0., 'std': 1.}
        scaling_da = scaling_df.to_xarray().astype('float32')
        try:
            self._input_scaling = scaling_da.sel(index=self.ds.channel_in.values).rename({'index': 'channel_in'})
        except (ValueError, KeyError) as e:
            raise KeyError(f"one or more of the input data variables f{list(self.ds.channel_in.values)} not found in "
                           f"the scaling config dict data.scaling ({list(self.scaling.keys())})") from e
        try:
            self._target_scaling = scaling_da.sel(index=self.ds.channel_out.values).rename({'index': 'channel_out'})
        except (ValueError, KeyError) as e:
            raise KeyError(f"one or more of the target data variables f{list(self.ds.channel_out.values)} not found "
                           f"in the scaling config dict data.scaling ({list(self.scaling.keys())})") from e

    def __len__(self):
        return self._time_dim * self._step_dim

    def __get_valid_time(self, item):
        t, s = self.get_time_step_index(item)
        return self.ds['time'][t].values + self.ds['step'][s].values

    def get_time_step_index(self, item):
        t, s = np.unravel_index(item, (self._time_dim, self._step_dim))
        return slice(t * self.batch_size, (t + 1) * self.batch_size), s

    def __getitem__(self, item):
        time_slice, step_index = self.get_time_step_index(item)
        logger.log(1, f"data sample time: {self.ds.time.values[time_slice]}, step: {self.ds.step.values[step_index]}")
        sample = {'time': time_slice, 'step': step_index}
        if isinstance(self.subsample_size, int) and self.subsample_size < self.ds.sizes['number']:
            if self.shuffle:
                members = np.random.choice(self.ds.sizes['number'], size=self.subsample_size, replace=False)
            else:
                members = np.arange(self.subsample_size)
            sample['number'] = members
        elif isinstance(self.subsample_size, Sequence):
            sample['number'] = self.subsample_size
        target_sample = {'obs_time': self.__get_valid_time(item)}
        inputs = (self.ds['inputs'].isel(**sample) - self._input_scaling['mean']) / self._input_scaling['std']
        # Get additional metadata added to inputs
        has_metadata = any(['constants' in self.ds.data_vars, self.add_insolation, self.add_lead_time])
        if has_metadata:
            metadata = []
            if self.add_insolation:
                sol = insolation(self.__get_valid_time(item), self.ds.latitude.values, self.ds.longitude.values,
                                 enforce_2d=True, clip_zero=False, daily=self.insolation_type == 'daily')
                metadata.append(xr.DataArray(
                    sol[:, None],
                    dims=['time', 'channel_c', 'latitude', 'longitude'],
                    coords={
                        'time': inputs.time,
                        'channel_c': ['insolation'],
                        'latitude': self.ds.latitude,
                        'longitude': self.ds.longitude
                    }
                ))
            if self.add_lead_time:
                step = float(self.ds.step.values[step_index].astype('timedelta64[h]').astype('float')) / 168.
                metadata.append(xr.DataArray(
                    np.full((1, self.ds.sizes['latitude'], self.ds.sizes['longitude']), step, dtype='float32'),
                    dims=['channel_c', 'latitude', 'longitude'],
                    coords={
                        'channel_c': ['lead_time'],
                        'latitude': self.ds.latitude,
                        'longitude': self.ds.longitude
                    }
                ))
            if 'constants' in self.ds.data_vars:
                metadata.append(self.ds['constants'])
            metadata = xr.concat(metadata, dim='channel_c').rename('metadata')
        targets = (self.ds['targets'].sel(**target_sample) - self._target_scaling['mean']) / \
            self._target_scaling['std']
        if self.target_clipping is not None:
            targets = targets.clip(*self.target_clipping)
        if self.fill_nans_in_input:
            inputs = inputs.fillna(0.)
        if self.check_nans and np.isnan(inputs).sum() > 0:
            logger.error("found NaN data; logging occurence information")
            print(f"data sample time: {self.ds.time.values[time_slice]}, step: {self.ds.step.values[step_index]}")
            print(f"missing values per channel_in: "
                  f"{np.isnan(inputs).sum([d for d in inputs.dims if d != 'channel_in']).compute()}")
        if self.check_nans and np.isnan(targets).sum() > 0:
            logger.error("found NaN data in targets; logging occurence information")
            print(f"data sample time: {self.ds.time.values[time_slice]}, step: {self.ds.step.values[step_index]}")
            print(f"missing values per channel_out: "
                  f"{np.isnan(targets).sum([d for d in targets.dims if d != 'channel_out']).compute()}")
        if self.return_da:
            if has_metadata:
                return inputs, targets, metadata
            return inputs, targets
        try:
            if has_metadata:
                return inputs.values, targets.values, metadata.values
            return inputs.values, targets.values
        except RuntimeError:
            logger.error("an unexpected error occurred when computing data")
            logger.error(f"input dataarray: {inputs}")
            logger.error(f"target dataarray: {targets}")
            if has_metadata:
                logger.error(f"metadata dataarray: {metadata}")
            raise


class IndexedVerifiedEnsembleDataset(VerifiedEnsembleDataset):
    """
    This alternative to VerifiedEnsembleDataset only modifies the __getitem__ method
    to return the getitem index as part of the batch.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __getitem__(self, item: int) -> Any:
        return *super().__getitem__(item), item
