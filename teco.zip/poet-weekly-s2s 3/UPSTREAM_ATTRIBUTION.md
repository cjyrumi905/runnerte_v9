# Upstream attribution

The POET model in this distribution is derived from the official ECMWF-Lab implementation:

- Repository: https://github.com/ecmwf-lab/poet
- Project: POET — Post-processing of Ensembles with Transformers
- Original implementation and research citation are documented in the upstream repository README.

This package includes additional weekly/subseasonal data, training, inference, and pipeline code. The retained `LICENSE` contains the applicable license and copyright notices. No claim is made that the upstream model or its original research was authored by this distribution's maintainer.
