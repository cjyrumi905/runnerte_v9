from typing import Optional, Sequence, Union

import numpy as np
import pandas as pd
import xarray as xr


def _convert_time_step(dt):  # pylint: disable=invalid-name
    return pd.Timedelta(hours=dt) if isinstance(dt, int) else pd.Timedelta(dt)


def get_weekly_steps(weeks):
    """
    Get a sequence of lead times for weekly forecasts. Default treatment for weekly forecasts is steps of 6 hours.

    :param weeks: number of weeks to forecast
    """
    return np.arange(pd.Timedelta('6H'), pd.Timedelta('7D') * weeks, pd.Timedelta('6H'))


def obs_to_verification(
        obs: Union[xr.Dataset, xr.DataArray],
        max_lead: Union[pd.Timedelta, int] = 168,
        steps: Optional[Sequence[pd.Timestamp]] = None,
        issue_times: Optional[Sequence[pd.Timestamp]] = None
) -> Union[xr.Dataset, xr.DataArray]:
    """
    Convert a Dataset or DataArray of continuous time-series observations
    according to the obs data spec into the forecast data spec for direct
    comparison to forecasts.

    Parameters
    ----------
    obs: xarray Dataset or DataArray of observation data
    max_lead: maximum lead time for verification dataset. If int, interpreted
        as hours.
    steps: optional sequence of lead times to retain
    issue_times: issue times for the forecast result. If
        not specified, uses all available obs times.
    """
    issue_dim = 'time'
    lead_dim = 'step'
    max_lead = _convert_time_step(max_lead)
    if issue_times is None:
        issue_times = obs['time'].values
    obs_series = []
    for issue in issue_times:
        try:
            obs_series.append(
                obs.sel(**{'time': slice(issue, issue + max_lead)}).rename({'time': lead_dim})
            )
            obs_series[-1] = obs_series[-1].assign_coords(
                **{issue_dim: [issue], lead_dim: obs_series[-1][lead_dim] - issue})
        except Exception as e:  # pylint: disable=broad-exception-caught
            print(f'Failed to sel {issue} due to {e}')
            continue
    verification_ds = xr.concat(obs_series, dim=issue_dim)
    if steps is not None:
        verification_ds = verification_ds.sel(**{lead_dim: steps})

    return verification_ds


def combine_forecast_and_obs(
        forecast: xr.Dataset,
        observation: xr.Dataset,
        variable: Optional[str] = '2m_temperature_0',
        interpolate_method: Optional[str] = None,
        weekly: Union[bool, str] = False,
        strict_lead_times: bool = True
) -> xr.Dataset:
    """
    Convert an observation dataset into a format suitable for direct comparison to a forecast, then compute
    the difference between forecast-observation.
    :param forecast: xarray Dataset of forecast data
    :param observation: xarray Dataset of observation data
    :param variable: str name of variable in forecast and observation
    :param interpolate_method: str method for interpolating forecast to observation grid
    :param weekly: if True, aggregate forecasts into weekly averages. If 'obs', aggregate obs only (assumes forecast
        is already weekly)
    :param strict_lead_times: if True, match exact lead times between forecast and observation, and omit any forecasts
        that have any missing lead times in observations.
    """
    required_dims = ['time', 'step', 'latitude', 'longitude']
    if any(d not in forecast.dims for d in required_dims):
        raise ValueError(f"forecast dataset missing one or more dimensions from {required_dims}: \n{forecast}")
    if variable not in observation.data_vars:
        raise ValueError(f"observation missing variable {variable}")
    if variable not in forecast.data_vars:
        raise ValueError(f"forecast missing variable {variable}")

    verification_steps = get_weekly_steps(int(forecast.step.max())) if weekly == 'obs' else \
        forecast.coords['step'].values
    max_lead = pd.Timedelta(days=7 * forecast.coords['step'].values.max()) if weekly == 'obs' else \
        pd.Timedelta(forecast.coords['step'].values.max())
    verification = obs_to_verification(
        observation[[variable]],
        max_lead=max_lead,
        issue_times=forecast.coords['time'].values,
        steps=verification_steps if strict_lead_times else None
    )
    if interpolate_method is not None:
        # Use scipy library; make sure to convert back to float32
        forecasted = forecast[variable].interp(
            latitude=observation.latitude,
            longitude=observation.longitude,
            method=interpolate_method
        ).astype('float32')
    else:
        # Small tolerance for round-off error
        forecasted = forecast[variable].sel(
            latitude=observation.latitude,
            longitude=observation.longitude,
            method='nearest',
            tolerance=1e-5
        )
    if weekly:
        verification = aggregate_forecast_weekly(verification, variable)
        if weekly != 'obs':
            forecasted = aggregate_forecast_weekly(forecasted, variable)
    diff = forecasted - verification[variable]
    data = xr.Dataset()
    data['diff'] = diff
    data['forecast'] = forecasted
    return data


def climatology_to_forecast(climo, variable, issue_times, steps):
    """
    Convert a climatology dataset into a forecast dataset, with the given issue times and lead times.

    Parameters
    ----------
    climo: xarray Dataset or DataArray of climatology data
    variable: str name of variable in climo
    issue_times: issue times for the forecast result
    steps: lead times for the forecast result
    """
    climo_series = []
    climo_variable = variable if variable in climo.data_vars else f"{variable}_mean"
    try:
        climo = climo.drop('step')
    except ValueError:
        pass
    for issue in issue_times:
        valid_times = pd.Timestamp(issue) + pd.to_timedelta(steps)
        climo_series.append(xr.concat(
            [climo[[climo_variable]].sel(doy=[vt.dayofyear], hod=vt.hour).rename({'doy': 'step'}).drop('hod')
             .assign_coords(time=issue, step=[step]) for step, vt in zip(steps, valid_times)],
            dim='step'
        ))
    climo_forecast = xr.concat(climo_series, dim='time')
    return climo_forecast.rename({variable: 'forecast'})


def generate_persistence_forecast(ds, variable, issue_times, steps, correct_diurnal=False, weekly=False):
    """
    Generate a persistence forecast from the given dataset, variable, issue times, and lead times.

    Parameters
    ----------
    ds: xarray Dataset or DataArray of observation data
    variable: str name of variable in observations
    issue_times: issue times for the forecast result
    steps: lead times for the forecast result
    correct_diurnal: if True, correct the persistence forecast for the diurnal cycle by using a few past steps
    weekly: if True, use the past weekly mean as persistence forecast
    """
    if weekly:
        step_size = pd.Timedelta(steps[1] - steps[0])
        # Use a trick for weekly-averaged forecasts - only need #weeks steps
        week_steps = np.arange(0, np.max(steps).astype('timedelta64[h]').astype(int) // 168) + 1
        forecasts = []
        for issue in issue_times:
            selection = ds[[variable]].sel(time=slice(issue - pd.Timedelta(days=7) + step_size, issue))
            selection = selection.resample({'time': step_size}).nearest().mean('time')
            forecasts.append(xr.concat([selection.assign_coords(time=issue, step=s) for s in week_steps], dim='step'))
        # Also add the verification now if using weekly forecasts
        verification = obs_to_verification(
            ds[[variable]],
            max_lead=pd.Timedelta(steps.max()),
            issue_times=issue_times
        )
        verification = aggregate_forecast_weekly(verification, variable)
        forecasted = xr.concat(forecasts, dim='time')[variable]
        diff = forecasted - verification.sel(step=forecasted.step)[variable]
        data = xr.Dataset()
        data['diff'] = diff
        data['forecast'] = forecasted
        return data
    if correct_diurnal:
        raise NotImplementedError('correct_diurnal=True not yet implemented')
    return xr.concat([ds[[variable]].sel(time=issue_times).assign_coords(step=s) for s in steps], dim='step')


def aggregate_forecast_weekly(forecast, variable=None):  # pylint: disable=unused-argument
    weekly = forecast.sel(step=slice(pd.Timedelta('1H'), None))
    weekly = weekly.assign_coords(step=(weekly.step.values.astype('timedelta64[h]').astype(int) - 1) // 168 + 1)
    weekly = weekly.groupby('step').mean('step')
    return weekly
