# Modified from WeatherBench2 repo:
# https://github.com/google-research/weatherbench2/blob/main/weatherbench2/metrics.py
# ==============================================================================
import numpy as np
import xarray as xr
from scipy import stats

import dataclasses
import typing as t

AVERAGE_DIMS = ('time', 'latitude', 'longitude')
SPATIAL_PLOT_AVERAGE_DIMS = ('time')


def _get_latitude_weighting(data):
    weights = np.cos(np.deg2rad(data.coords['latitude']))
    weights /= weights.mean()
    return weights


def _get_n_ensemble(
        ds: xr.Dataset,
        ensemble_dim: str,
        expect_n_ensemble_at_least: int = 1
        ) -> int:
    """Returns the size of `ensemble_dim`, optionally asserting size at least."""
    if ensemble_dim not in ds.dims:
        raise ValueError(f"{ensemble_dim=} not found in {ds.dims=}")
    # DK: modified next line
    n_ensemble = len(ds[ensemble_dim])

    if n_ensemble < expect_n_ensemble_at_least:
        raise ValueError(
            f"{n_ensemble=} is less than expected size of "
            f"{expect_n_ensemble_at_least}"
        )
    return n_ensemble


@dataclasses.dataclass
class Metric:
    """Base class for metrics."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """Evaluate this metric on a temporal chunk of data.

        The metric should be evaluated independently for each time (averaging over
        time is performed later, on multiple chunks). Thus `forecast` and `truth`
        chunks should cover the full spatial extent of the data, but not necessarily
        all times.

        Args:
            forecast: dataset of forecasts to evaluate.
            truth: dataset of ground truth. Should have the same variables as
            forecast.
            region: Region class. .apply() method is called inside before spatial
            averaging.

        Returns:
            Dataset with metric results for each variable in forecasts/truth, without
            spatial dimensions (latitude/longitude).
        """
        raise NotImplementedError

    def compute(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """Evaluate this metric on datasets with full temporal coverages."""
        if "time" in forecast.dims:
            avg_dim = "time"
        elif "init_time" in forecast.dims:
            avg_dim = "init_time"
        else:
            raise ValueError(
                f"Forecast has neither valid_time or init_time dimension {forecast}"
            )
        return self.compute_chunk(forecast, truth, lsm=lsm).mean(avg_dim)


@dataclasses.dataclass
class EnsembleMetric(Metric):
    """Ensemble metric base class."""

    ensemble_dim: str = 'number'

    def _ensemble_slice(self, ds: xr.Dataset, slice_obj: slice) -> xr.Dataset:
        """Slice `ds` and assign coords to [0, ..., len(slice)]."""
        ds = ds.isel({self.ensemble_dim: slice_obj})
        return ds.assign_coords(
            {self.ensemble_dim: np.arange(ds.dims[self.ensemble_dim])}
        )

    def compute(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """Evaluate this metric on datasets with full temporal coverages."""
        result = super().compute(forecast, truth, lsm=lsm)
        return result.assign_attrs(ensemble_size=forecast[self.ensemble_dim].size)


@dataclasses.dataclass
class CRPS(EnsembleMetric):
    """Continuous Ranked Probability Score, averaged over space and time.

    Given ground truth scalar random variable Y, and two iid predictions X, X',
    the Continuously Ranked Probability Score is defined as
        CRPS = E|X - Y| - 0.5 * E|X - X'|
    where `E` is mathematical expectation, and |⋅| is absolute value. CRPS has a
    unique minimum when X is distributed the same as Y.

    The associated spread/skill ratio is
        SS(CRPS) = E|X - X'| / E|X - Y|.
    Assuming Y is non-constant, SS(CRPS) = 0 only when X is constant. Since X, X'
    are independent, |X - Y| < |X - Y| + |X - Y|, and thus 0 ≤ SS(CRPS) < 2.
    If X has the same distribution as Y, SS(CRPS) = 1. Caution, it is possible for
    SS(CRPS) = 1 even when X and Y have different distributions.

    CRPS for multi-dimensional random variables is computed as a weighted average
    over components. The minimum is achieved by any prediction X with the correct
    marginals.

    In our case, each prediction is conditioned on the start time t. Given T
    different start times, this class estimates time and ensemble averaged
    quantities for each tendency "V", producing entries
        V_spread := (1 / T) Σₜ ‖Xₜ - Xₜ'‖
        V_skill  := (1 / T) Σₜ ‖Xₜ - Yₜ‖
        V_score  := V_skill - 0.5 * V_spread
    ‖⋅‖ is the area-averaged L1 norm. Estimation is done separately for each
    tendency, level, and lag time.

    If N ensemble members are available, the ensemble mean is taken using the PWM
    method from [Zamo & Naveau, 2018].

    So long as 2 or more ensemble members are used, the estimates of spread, skill
    and CRPS are unbiased at each time. Therefore, assuming some ergodicity, one
    can average over many time points and obtain highly accurate estimates.

    NaN values propagate through and result in NaN in the corresponding output
    position.

    References:
    [Gneiting & Raftery, 2012], Strictly Proper Scoring Rules, Prediction, and
        Estimation
    [Zamo & Naveau, 2018], Estimation of the Continuous Ranked Probability Score
        with Limited Information and Applications to Ensemble Weather Forecasts.
    """

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPS, averaged over space, for a time chunk of data."""
        return CRPSSkill(self.ensemble_dim).compute_chunk(
            forecast, truth, lsm=lsm
        ) - 0.5 * CRPSSpread(self.ensemble_dim).compute_chunk(
            forecast, truth, lsm=lsm
        )


@dataclasses.dataclass
class CRPSSpread(EnsembleMetric):
    """The spread measure associated with CRPS, E|X - X'|."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPSSpread, averaged over space, for a time chunk of data."""
        return _spatial_average(
            _pointwise_crps_spread(forecast, truth, self.ensemble_dim),
            lsm=lsm,
        )


@dataclasses.dataclass
class CRPSSkill(EnsembleMetric):
    """The skill measure associated with CRPS, E|X - Y|."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPSSkill, averaged over space, for a time chunk of data."""
        return _spatial_average(
            _pointwise_crps_skill(forecast, truth, self.ensemble_dim),
            lsm=lsm,
        )


@dataclasses.dataclass
class SpatialCRPS(EnsembleMetric):
    """CRPS without spatial averaging."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPS, averaged over space, for a time chunk of data."""
        return SpatialCRPSSkill(self.ensemble_dim).compute_chunk(
            forecast, truth, lsm=lsm
        ) - 0.5 * SpatialCRPSSpread(self.ensemble_dim).compute_chunk(
            forecast, truth, lsm=lsm
        )


@dataclasses.dataclass
class SpatialCRPSSpread(EnsembleMetric):
    """CRPSSpread without spatial averaging."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPSSpread, averaged over space, for a time chunk of data."""
        return _pointwise_crps_spread(forecast, truth, self.ensemble_dim)


@dataclasses.dataclass
class SpatialCRPSSkill(EnsembleMetric):
    """CRPSSkill without spatial averaging."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """CRPSSkill, averaged over space, for a time chunk of data."""
        return _pointwise_crps_skill(forecast, truth, self.ensemble_dim)


def _pointwise_crps_spread(
    forecast: xr.Dataset, truth: xr.Dataset, ensemble_dim: str
) -> xr.Dataset:
    """CRPS spread at each point in truth, averaged over ensemble only."""
    del truth  # unused
    n_ensemble = _get_n_ensemble(forecast, ensemble_dim)
    if n_ensemble < 2:
        return xr.zeros_like(forecast.isel({ensemble_dim: 0}))

    # one_half_spread is ̂̂λ₂ from Zamo. That is, with n_ensemble = M,
    #   λ₂ = 1 / (2 M (M - 1)) Σ_{i,j=1}^M |Xi - Xj|
    # See the definition of eFAIR and then
    # eqn 3 (appendix B), which shows that this double summation of absolute
    # differences can be written as a sum involving sorted elements multiplied
    # by their index. That is, if X1 < X2 < ... < XM,
    #   λ₂ = 1 / (M(M-1)) Σ_{i,j=1}^M (2*i - M - 1) Xi.
    # The term (2*i - M - 1) is +1 times the number of terms Xi is greater than,
    # and -1 times the number of terms Xi is less than.
    # Here we do not sort, but instead compute the rank of each element, multiply
    # appropriately, then sum. We prefer this second form, since it involves an
    # O(M Log[M]) compute and O(M) memory usage, whereas the first is O(M²) in
    # compute and memory.
    rank = _rank_ds(forecast, ensemble_dim)
    return (
        2
        * (
            ((2 * rank - n_ensemble - 1) * forecast).mean(
                ensemble_dim, skipna=False
            )
        )
        / (n_ensemble - 1)
    )


def _pointwise_crps_skill(
    forecast: xr.Dataset, truth: xr.Dataset, ensemble_dim: str
) -> xr.Dataset:
    """CRPS skill at each point in truth, averaged over ensemble only."""
    _get_n_ensemble(forecast, ensemble_dim)  # Will raise if no ensembles.
    return abs(truth - forecast).mean(ensemble_dim, skipna=False)


def _rank_ds(ds: xr.Dataset, dim: str) -> xr.Dataset:
    """The ranking of `ds` along `dim`, with 1 being the smallest entry."""

    def _rank_da(da: xr.DataArray) -> np.ndarray:
        return stats.rankdata(da.values, method="ordinal", axis=da.dims.index(dim))

    return ds.copy(data={k: _rank_da(v) for k, v in ds.items()})


def _spatial_average(
    dataset: xr.Dataset,
    lsm: t.Optional[xr.DataArray] = None,
    skipna: bool = False
) -> xr.Dataset:
    """Compute spatial average after applying region mask.

    Args:
        dataset: Metric dataset as a function of latitude/longitude.
        lsm: DataArray with land sea mask (optional).
        skipna: Skip NaNs in spatial mean.

    Returns:
        dataset: Spatially averaged metric.
    """
    weights = _get_latitude_weighting(dataset)
    if lsm is not None:
        weights = weights * lsm.astype(float)

    return dataset.weighted(weights).mean(
        ["latitude", "longitude"], skipna=skipna
    )


def _spatial_average_l2_norm(
    dataset: xr.Dataset,
    lsm: t.Optional[xr.DataArray] = None,
    skipna: bool = False
) -> xr.Dataset:
    """Helper function to compute sqrt(spatial_average(ds**2))."""
    return np.sqrt(_spatial_average(dataset**2, lsm=lsm, skipna=skipna))


@dataclasses.dataclass
class GaussianCRPS(EnsembleMetric):
    """The analytical formulation of CRPS for a Gaussian."""

    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """GaussianCRPS, averaged over space, for a time chunk of data."""
        forecast_m = forecast.mean(self.ensemble_dim, skipna=False)
        forecast_std = forecast.std(self.ensemble_dim, skipna=False)
        # rename variables in std dataset:
        suffix = '_std'
        # Create a dictionary to map old variable names to new variable names with the suffix
        rename_dict = {var: f"{var}{suffix}" for var in forecast_std.data_vars}
        # Rename the variables in the dataset
        forecast_std = forecast_std.rename_vars(rename_dict)
        # merge the mean and std forecasts.
        forecast_all = xr.combine_by_coords([forecast_m, forecast_std], combine_attrs="drop_conflicts")
        return _spatial_average(
            _pointwise_gaussian_crps(forecast_all, truth), lsm=lsm
        )


def _pointwise_gaussian_crps(
    forecast: xr.Dataset, truth: xr.Dataset
) -> xr.Dataset:
    r"""Returns pointwise CRPS of a Gaussian distribution with mean and std values.

    CRPS of a Gaussian distribution with mean value m and standard deviation s
    can be computed as

    CRPS(F_(m,s), y) = s * {(y-m)/s * [2G((y-m)/s) - 1] + 2g((y-m)/s) -
    1/\sqrt(\pi))}

    where G and g denote the CDF and PDF of a standard Gaussian distribution,
    respectively.
    References:
    [Gneiting, Raftery, Westveld III, Goldman, 2005], Calibrated Probabilistic
    Forecasting Using Ensemble Model Output Statistics and Minimum CRPS Estimation
    DOI: https://doi.org/10.1175/MWR2904.1

    Args:
    forecast: A forecast dataset.
    truth: A ground truth dataset.

    Returns:
    xr.Dataset: Pointwise calculated crps for a Gaussian distribution.
    """
    var_list = []
    dataset = {}
    for var in forecast.keys():
        if f"{var}_std" in forecast.keys():
            var_list.append(var)
    for var_name in var_list:
        norm_diff = (forecast[var_name] - truth[var_name]) / forecast[
            f"{var_name}_std"
        ]
        value = forecast[f"{var_name}_std"] * (
            norm_diff * (2 * xr.apply_ufunc(stats.norm.cdf, norm_diff.load()) - 1)
            + 2 * xr.apply_ufunc(stats.norm.pdf, norm_diff.load())
            - 1 / np.sqrt(np.pi)
        )
        dataset[var_name] = value
    return xr.Dataset(dataset, coords=forecast.coords)


@dataclasses.dataclass
class GaussianVariance(Metric):
    """The variance of a Gaussian forecast."""

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """GaussianVariance, averaged over space, for a time chunk of data."""
        del truth  # unused
        var_list = []
        dataset = {}
        for var in forecast.keys():
            if f"{var}_std" in forecast.keys():
                var_list.append(var)
        for var_name in var_list:
            variance = forecast[f"{var_name}_std"] * forecast[f"{var_name}_std"]
            dataset[var_name] = variance

        return _spatial_average(
            xr.Dataset(dataset, coords=forecast.coords),
            lsm=lsm,
        )


class EnsembleVariance(EnsembleMetric):
    """The variance of an ensemble of forecasts."""

    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """EnsembleVariance, averaged over space, and other dims, for a time chunk of data."""
        del truth  # unused
        n_ensemble = _get_n_ensemble(forecast, self.ensemble_dim)

        if n_ensemble == 1:
            return xr.zeros_like(
              # Compute the average, even though we return zeros_like. Why? Because,
              # this will preserve the scalar values of lat/lon coords correctly.
              _spatial_average(forecast, lsm=lsm).mean(self.ensemble_dim, skipna=False)
            )
        else:
            return _spatial_average(
              forecast.var(self.ensemble_dim, skipna=False), lsm=lsm
            )


@dataclasses.dataclass
class SpatialEnsembleVariance(EnsembleMetric):
    """Ensemble variance without spatial averaging."""

    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """Ensemble variance, for a time chunk of data."""
        del truth  # unused
        n_ensemble = _get_n_ensemble(forecast, self.ensemble_dim)

        if n_ensemble == 1:
            return xr.zeros_like(
              # Compute the average, even though we return zeros_like. Why? Because,
              # this will preserve the scalar values of lat/lon coords correctly.
              forecast
            ).mean(self.ensemble_dim, skipna=False)
        else:
            return forecast.var(self.ensemble_dim, skipna=False)


@dataclasses.dataclass
class EnsembleSpreadSkillRatio(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """SpreadSkill Ratio, averaged over space, for a time chunk of data."""
        ensemble_size = _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt((ensemble_size + 1) / ensemble_size) * \
            EnsembleSpread(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm) / \
            EnsembleMeanSkill(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm)


@dataclasses.dataclass
class EnsembleMeanSkill(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleMeanSkill, averaged over space, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt(EnsembleMeanMSE(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm))


@dataclasses.dataclass
class EnsembleSpread(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleSpread, averaged over space, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt(EnsembleVariance(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm))


@dataclasses.dataclass
class EnsembleMeanMSE(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleMeanMSE, averaged over space, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return _spatial_average((truth - forecast.mean(self.ensemble_dim, skipna=False)) ** 2,
                                lsm=lsm)


@dataclasses.dataclass
class SpatialEnsembleSpreadSkillRatio(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleMeanRMSE, averaged over space, for a time chunk of data."""
        ensemble_size = _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt((ensemble_size + 1) / ensemble_size) * \
            SpatialEnsembleSpread(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm) / \
            SpatialEnsembleMeanSkill(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm)


@dataclasses.dataclass
class SpatialEnsembleMeanSkill(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleMeanRMSE, averaged over space, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt(SpatialEnsembleMeanMSE(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm))


@dataclasses.dataclass
class SpatialEnsembleSpread(EnsembleMetric):
    """Mean square error between the ensemble mean and ground truth."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """EnsembleMeanRMSE, averaged over space, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.
        return np.sqrt(SpatialEnsembleVariance(self.ensemble_dim).compute_chunk(forecast, truth, lsm=lsm))


@dataclasses.dataclass
class SpatialEnsembleMeanMSE(EnsembleMetric):
    """EnsembleMeanMSE (MSE, not RMSE), without spatial averaging."""
    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """Squared error in the ensemble mean, for a time chunk of data."""
        _get_n_ensemble(forecast, self.ensemble_dim)  # Will raise if no ensembles.

        return (truth - forecast.mean(self.ensemble_dim, skipna=False)) ** 2


@dataclasses.dataclass
class SpatialEnsembleStddevSqrt(EnsembleMetric):
    """The standard deviation of an ensemble of forecasts.

  This SqrtBeforeTimeAvg metric takes a square root before any time averaging.
  Most users will prefer to use EnsembleVariance and then take a square root in
  user code after running the evaluate script.

  Given predictive ensemble Xₜ at times t = (1,..., T),
    EnsembleStddevSqrtBeforeTimeAvg := (1 / T) Σₜ ‖σ(Xₜ)‖
  Above σ(Xₜ) is element-wise standard deviation, and ‖⋅‖ is an area-weighted
  L2 norm.

  Estimation is done separately for each tendency, level, and lag time.
  Ensembles of size 1 lead SPREAD=0, otherwise the unbiased sample standard
  deviation is used.

  This estimator has a slight amount of bias, since ‖σ(Xₜ)‖ has bias
  proportional to 1 / (ensemble_size * grid_size).

  NaN values propagate through and result in NaN in the corresponding output
  position.
  """

    def compute_chunk(
      self,
      forecast: xr.Dataset,
      truth: xr.Dataset,
      lsm: t.Optional[xr.DataArray] = None
    ) -> xr.Dataset:
        """Ensemble Stddev, averaged over space, for a time chunk of data."""
        del truth  # unused
        n_ensemble = _get_n_ensemble(forecast, self.ensemble_dim)

        if n_ensemble == 1:
            return xr.zeros_like(
              # Compute the average, even though we return zeros_like. Why? Because,
              # this will preserve the scalar values of lat/lon coords correctly.
              forecast.mean(self.ensemble_dim, skipna=False))
        else:
            return forecast.std(self.ensemble_dim, skipna=False)


class RankHistogram(EnsembleMetric):
    """Histogram of truth's rank with respect to forecast ensemble members.

    Given a K member ensemble {Xᵢ}, and ground truth Y, the rank of Y is the count
    of ensemble members less than Y. This class expresses that rank with one-hot
    encoding, which facilitates averaging/summation (typically over time) to form
    rank histograms. The histograms will have K+1 bins, and are indexed by 'bin'.

    This class also allows aggregation of the bins into num_bins ≤ K + 1 provided
    num_bins evently divides K + 1. This reduces the size of output files, but is
    equivalent to averaging default results along the 'bin' dimension.

    If these one-hot encodings are averaged over N times, a well calibrated
    forecast should contain roughly equal values in the bins. The bin variance
    will be (num_bins - 1) / (N num_bins²). Since the expected value is
    1 / num_bins, the relative error is
    Sqrt(variance) / expected = Sqrt((num_bins - 1) / N).
    """

    def __init__(
      self,
      ensemble_dim: str = 'number',
      num_bins: t.Optional[int] = None,
    ):
        """Initializes a RankHistogram.

        Args:
          ensemble_dim: Dimension indexing ensemble member.
          num_bins: Number of bins in histogram. If None, the number of bins will be
            `ensemble_size + 1`. If provided, `num_bins` must evenly divide into
            `ensemble_size + 1`.
        """
        super().__init__(ensemble_dim=ensemble_dim)
        self.num_bins = num_bins

    def _num_bins_actual(self, ensemble_size: int) -> int:
        default_n_bins = ensemble_size + 1
        if self.num_bins is None:
            return default_n_bins
        if default_n_bins % self.num_bins:
            raise ValueError(
              f"Cannot bin data with {ensemble_size=} into {self.num_bins} bins"
            )
        return self.num_bins

    def _bin_ranks(self, ensemble_size: int, ranks: xr.DataArray):
        """Transforms ensemble rank into bin membership."""
        default_n_bins = ensemble_size + 1
        num_bins = self._num_bins_actual(ensemble_size)
        reduction_factor = default_n_bins // num_bins
        if reduction_factor == 1:
            return ranks
        else:
            return ranks // reduction_factor

    def compute_chunk(
        self,
        forecast: xr.Dataset,
        truth: xr.Dataset,
        lsm: t.Optional[xr.DataArray] = None,
    ) -> xr.Dataset:
        """Computes one-hot encoding of rank on a chunk of forecast/truth."""
        # Create a fake ensemble member for truth. This is for concatenation.
        truth_realization = forecast[self.ensemble_dim].data.min() - 1
        truth = truth.assign_coords({self.ensemble_dim: truth_realization})
        # Forecast typically already has an ensemble coord...but sometimes it will
        # have an ensemble *dim* but not a coord, and this will mess up xr.concat.
        forecast = forecast.assign_coords(
            {self.ensemble_dim: forecast[self.ensemble_dim]}
        )
        combined = xr.concat([truth, forecast], dim=self.ensemble_dim)

        def array_rank_one_hot(da: xr.DataArray) -> xr.DataArray:
            ensemble_size = forecast.sizes[self.ensemble_dim]
            num_bins = self._num_bins_actual(ensemble_size)
            # order has the same dims as da, which is
            #   concat([truth, forecast], ensemble_dim)
            # da = da.compute()
            # Create mask for valid (non-NaN) truth values
            truth_data = da.sel({self.ensemble_dim: truth_realization})
            valid_mask = ~np.isnan(truth_data)
            order = xr.apply_ufunc(np.argsort, da,
                                   input_core_dims=[da.dims],
                                   output_core_dims=[da.dims],
                                   dask='parallelized',
                                   output_dtypes=[int],
                                   kwargs={'axis': da.dims.index(self.ensemble_dim),
                                           },
                                   dask_gufunc_kwargs={'allow_rechunk': True})
            # order = da.argsort(axis=da.dims.index(self.ensemble_dim))

            # Since we *prepended* truth to forecast, argmin will give the location of
            # truth in the results of argsort. Therefore, ranks is the positional
            # order of the truth realization.
            # ranks has the same dims as forecast, with ensemble_dim dropped.
            ranks = order.argmin(self.ensemble_dim)
            ranks = self._bin_ranks(ensemble_size, ranks)

            # Create one-hot encoding
            one_hot = ranks.expand_dims(bins=np.arange(num_bins), axis=-1).copy(
                data=np.eye(num_bins)[ranks.values],
            )

            # Mask out areas where truth was NaN
            one_hot = one_hot.where(valid_mask, np.nan)

            return one_hot
        spatial_rh = combined.map(array_rank_one_hot, keep_attrs=False)
        non_spatial_rh = spatial_rh.mean(['latitude', 'longitude'], skipna=True)
        return non_spatial_rh
