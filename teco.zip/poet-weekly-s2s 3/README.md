# POET Weekly S2S Forecasting

This repository packages a weekly/subseasonal adaptation of the ECMWF POET ensemble post-processing model.

## Contents

- `poet/`: POET model, layers, losses, and utilities.
- `ens_transformer/`: ensemble-transformer components and probabilistic scoring.
- `data_loading/`: verified-ensemble datasets and Lightning data module.
- `data_pipelines/`: ECMWF S2S hindcast/forecast acquisition and weekly aggregation utilities.
- `configs/poet/`: model, training, and weekly dataset configurations.
- `scripts/`: training, inference, and evaluation entry points.
- `components/`: portable command entry points and execution notes.
- `evaluation/`: ensemble verification metrics and helpers.

## Weekly configurations

Three data configurations are included:

- `configs/poet/data/weekly.yaml`
- `configs/poet/data/weekly_v2.yaml`
- `configs/poet/data/weekly_wus2.yaml`

They describe different weekly dataset layouts and variable naming conventions. Review each dataset path, target dataset, variable list, grid dimensions, lead-time range, and scaling configuration before training or inference. Storage roots such as `/weather-blob` and `/wxforecasting2` are environment-specific mount points and must be changed to match the runtime environment.

The model configuration output directory defaults to `./outputs/${experiment_name}` rather than a developer-specific absolute path.

## Training and inference

- Training entry point: `python scripts/train_poet.py ...` (Hydra configuration required).
- Inference entry point: `python scripts/inference_poet.py ...` (requires a trained checkpoint and the corresponding Hydra run configuration).
- Evaluation entry point: `python scripts/evaluate.py ...`.

The scripts are not turnkey without the expected datasets, dependencies, model configuration, and storage mounts. Consult the YAML configurations and script arguments before running.

## Data required

Training requires the configured ECMWF S2S hindcast ensemble fields, corresponding verification/target data (for example, ERA5 where configured), static fields/constants used by the data pipeline, and the dataset metadata needed to align initialization times, lead times, variables, ensemble members, and grids. Inference requires the matching real-time forecast fields, the same preprocessing/scaling assets and static constants, plus a compatible trained checkpoint and its Hydra configuration. The exact variables, date ranges, grid, and directory layout are defined by the selected YAML configuration.

## Spot or preemptible compute

Spot/preemptible workers may be reclaimed without warning. Do not keep the only copy of inputs, outputs, or checkpoints on ephemeral local disks. Stage the hindcast/forecast data, verification targets, static constants, configuration files, and required metadata in durable shared storage. Write Zarr stores with resumable/idempotent behavior, and persist training checkpoints (including optimizer and scheduler state when resuming training) to durable storage at regular intervals. Ensure partially written stores can be detected and safely resumed or rebuilt. No special provider-specific data format is required; the pipeline needs readable files, stable paths, and sufficient storage/throughput.

## Upstream provenance and licensing

This distribution is based on the official [ECMWF-Lab POET repository](https://github.com/ecmwf-lab/poet), with additional weekly S2S data handling, training, inference, and pipeline integration. See `UPSTREAM_ATTRIBUTION.md` and `LICENSE`. Required upstream license and copyright notices are retained.
