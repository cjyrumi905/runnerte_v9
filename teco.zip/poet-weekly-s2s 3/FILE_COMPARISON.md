# File comparison and portability notes

This distribution contains the weekly/subseasonal adaptation layered on the ECMWF-Lab POET codebase. The core model and training/inference implementations remain in place; see the source tree and `CHANGELOG.md` for this cleanup revision.

## This revision

- Removed provider-specific `components/*.yaml` manifests. They contained service-specific schemas and image references and could not be made portable by simply deleting those strings. The corresponding Python entry points remain available.
- Added `components/README.md` with direct-execution guidance.
- Changed the optional resume run identifier lookup to the generic `RUN_ID` environment variable.
- Removed generated `__pycache__` bytecode files.
- Expanded the README with required hindcast/forecast inputs, verification targets, static constants, metadata, checkpoints, and durable-storage requirements for preemptible compute.

## Important operational limitation

The removed YAML manifests previously supplied orchestration metadata and container definitions. Users must recreate those tasks in their chosen scheduler/orchestrator and provide a compatible Python environment with the repository dependencies. Removing the manifests does not replace that orchestration layer.
