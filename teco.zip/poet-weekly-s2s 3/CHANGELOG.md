# Changelog

## Portable weekly S2S distribution

- Removed provider-specific pipeline component manifests and container image references.
- Added portable component execution notes in `components/README.md`.
- Replaced provider-specific run-ID environment lookup with the generic `RUN_ID` variable.
- Removed generated Python bytecode/cache directories from the distribution.
- Added documentation describing the input datasets, verification targets, static fields, metadata, checkpoints, and durable-storage requirements for spot/preemptible compute.
- Generalized the evaluation script descriptions so they refer to ensemble forecasts rather than a specific forecast system.
- Removed embedded email addresses from source-file author comments while retaining author names.
- Retained the applicable upstream license and copyright notices in `LICENSE`.

No model architecture, tensor operation, loss calculation, data transformation, training loop, inference loop, or model configuration parameter was intentionally changed in this revision. Provider-specific YAML manifests were removed; their Python entry points remain.
